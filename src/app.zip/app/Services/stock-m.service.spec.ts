import { TestBed } from '@angular/core/testing';

import { StockMService } from './stock-m.service';

describe('StockMService', () => {
  let service: StockMService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(StockMService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
