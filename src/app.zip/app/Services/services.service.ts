import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, catchError, throwError, pipe } from 'rxjs';
import { Utilisateur } from '../Object/Utilisateur';
import { url } from '../Object/url';
import { Depense } from '../Object/Depense';
import { DateToShortDate } from '../Object/function';
import { Typedepense } from '../Object/Typedepense';
import { Chambre } from '../Object/Chambre';
import { Typechambre } from '../Object/Typechambre';
import { Restauration } from '../Object/Restauration';
import { table } from '../Object/tables';
import { Client } from '../Object/Client';
import { Charge } from '../Object/Charge';
import { Unite } from '../Object/Unite';
import { Famille } from '../Object/Famille';
import { Stock } from '../Object/Stock';
import { Ingredient } from '../Object/Ingredient';
import { Autre } from '../Object/Autres';

@Injectable({
  providedIn: 'root'
})
export class ServicesService {

  constructor(private http: HttpClient) { }

  Utilisateurs: Utilisateur[] = [];
  Actual!: Utilisateur;
  Depenses: Depense[] = [];
  Typedepenses: Typedepense[] = [];
  Chambres: Chambre[] = [];
  TypeChambres: Typechambre[] = [];
  Tables: table[] = [];
  Clients: Client[] = [];
  Charges: Charge[] = [];
  Unites: Unite[] = [];
  Familles: Famille[] = [];
  Stocks: Stock[] = [];
  Autres:Autre[] =[];

  Restauration: Restauration[] = [];

  // Utilisateur service function
  getActual() {
    return this.http.get(url + 'api/actual/utilisateur').pipe(
      map((res: any) => {
        this.Actual = res['data'];
        return this.Actual;
      }),
      catchError(this.handleError)
    )
  }

  getUtilisateurL() {
    return this.http.get(url + 'api/utilisateur/liste').pipe(
      map((res: any) => {
        this.Utilisateurs = res['data'];
        return this.Utilisateurs;
      }),
      catchError(this.handleError)
    );
  }

  newUtilisateur(u: Utilisateur) {
    return this.http.post(url + 'api/utilisateur/create', { data: u }).pipe(
      map((res: any) => {
        this.Utilisateurs = res['data'];
        return this.Utilisateurs;
      }),
      catchError(this.handleError)
    );
  }

  UpdateUtilisateur(u: Utilisateur) {
    return this.http.put(url + 'api/utilisateur/update/' + u.idutilisateur, { data: u }).pipe(
      map((res: any) => {
        this.Utilisateurs = res['data'];
        return this.Utilisateurs;
      }),
      catchError(this.handleError)
    );
  }

  DeleteUtilisateur(u: Utilisateur) {
    return this.http.delete(url + 'api/utilisateur/delete/' + u.idutilisateur).pipe(
      map((res: any) => {
        this.Utilisateurs = res['data'];
        return this.Utilisateurs;
      }),
      catchError(this.handleError)
    );
  }

  // Depense function start

  getTypedepenseList() {
    return this.http.get(url + 'api/typedepense/list').pipe(
      map((res: any) => {
        this.Typedepenses = res['data'];
        return this.Typedepenses;
      }),
      catchError(this.handleError)
    );
  }

  newTypedepense(t: Typedepense) {
    return this.http.post(url + 'api/typedepense/create', { data: t }).pipe(
      map((res: any) => {
        this.Typedepenses = res['data'];
        return this.Typedepenses;
      }),
      catchError(this.handleError)
    );
  }

  updateTypedepense(t: Typedepense) {
    return this.http.put(url + 'api/typedepense/update/' + t.idtyped, { data: t }).pipe(
      map((res: any) => {
        this.Typedepenses = res['data'];
        return this.Typedepenses;
      }),
      catchError(this.handleError)
    );
  }

  getDepenseList() {
    return this.http.get(url + 'api/depense/liste').pipe(
      map((res: any) => {
        this.Depenses = res['data'];
        this.Depenses.forEach((item) => {
          item.dated = DateToShortDate(item.dated);
        });
        return this.Depenses;
      }),
      catchError(this.handleError)
    );
  }

  NewDepense(d: Depense) {
    return this.http.post(url + 'api/depense/create/' + d.idutilisateur.idutilisateur, { data: d }).pipe(
      map((res: any) => {
        this.Depenses = res['data'];
        this.Depenses.forEach((item) => {
          item.dated = DateToShortDate(item.dated);
        });
        return this.Depenses;
      }),
      catchError(this.handleError)
    );
  }

  UpdateDepense(d: Depense) {
    return this.http.put(url + 'api/depense/update/' + d.iddepense, { data: d }).pipe(
      map((res: any) => {
        this.Depenses = res['data'];
        this.Depenses.forEach((item) => {
          item.dated = DateToShortDate(item.dated);
        });
        return this.Depenses;
      }),
      catchError(this.handleError)
    );
  }

  DeleteDepense(d: Depense) {
    return this.http.delete(url + 'api/depense/delete/' + d.iddepense).pipe(
      map((res: any) => {
        this.Depenses = res['data'];
        this.Depenses.forEach((item) => {
          item.dated = DateToShortDate(item.dated);
        });
        return this.Depenses;
      }),
      catchError(this.handleError)
    );
  }

  // Type chambre function start
  getTypechambreL() {
    return this.http.get(url + 'api/typechambre/liste').pipe(
      map((res: any) => {
        this.TypeChambres = res['data'];
        return this.TypeChambres;
      }),
      catchError(this.handleError)
    );
  }

  NewTypeChambre(t: Typechambre) {
    return this.http.post(url + 'api/typechambre/create', { data: t }).pipe(
      map((res: any) => {
        this.TypeChambres = res['data'];
        return this.TypeChambres;
      }),
      catchError(this.handleError)
    );
  }

  UpdateTypeChambre(t: Typechambre) {
    return this.http.put(url + 'api/typechambre/update/' + t.idtypec, { data: t }).pipe(
      map((res: any) => {
        this.TypeChambres = res['data'];
        return this.TypeChambres;
      }),
      catchError(this.handleError)
    );
  }

  DeleteTypeChambre(t: Typechambre) {
    return this.http.delete(url + 'api/typechambre/delete/' + t.idtypec).pipe(
      map((res: any) => {
        this.TypeChambres = res['data'];
        return this.TypeChambres;
      }),
      catchError(this.handleError)
    );
  }

  // Chambre function start
  getChambreList() {
    return this.http.get(url + 'api/chambre/liste').pipe(
      map((res: any) => {
        this.Chambres = res['data'];
        return this.Chambres;
      }),
      catchError(this.handleError)
    );
  }

  createChambre(c: Chambre) {
    return this.http.post(url + 'api/chambre/create/' + c.idtypec.idtypec, { data: c }).pipe(
      map((res: any) => {
        this.Chambres = res['data'];
        return this.Chambres;
      }),
      catchError(this.handleError)
    );
  }

  UpdateChambre(c: Chambre) {
    return this.http.put(url + 'api/chambre/update/' + c.idchambre, { data: c }).pipe(
      map((res: any) => {
        this.Chambres = res['data'];
        return this.Chambres;
      }),
      catchError(this.handleError)
    );
  }

  DeleteChambre(c: Chambre) {
    return this.http.delete(url + 'api/chambre/delete/' + c.idchambre).pipe(
      map((res: any) => {
        this.Chambres = res['data'];
        return this.Chambres;
      }),
      catchError(this.handleError)
    );
  }

  // Restauration function start
  getRestauration() {
    return this.http.get(url + 'api/restauration/liste').pipe(
      map((res: any) => {
        this.Restauration = res['data'];
        return this.Restauration;
      }),
      catchError(this.handleError)
    );
  }

  NewRestauration(r: Restauration) {
    return this.http.post(url + 'api/restauration/create', { data: r }).pipe(
      map((res: any) => {
        this.Restauration = res['data'];
        return this.Restauration;
      }),
      catchError(this.handleError)
    );
  }

  UpdateRestauration(r: Restauration) {
    return this.http.put(url + 'api/restauration/update/' + r.idrestauration, { data: r }).pipe(
      map((res: any) => {
        this.TypeChambres = res['data'];
        return this.TypeChambres;
      }),
      catchError(this.handleError)
    );
  }

  DeleteRestauration(r: Restauration) {
    return this.http.delete(url + 'api/restauration/delete/' + r.idrestauration).pipe(
      map((res: any) => {
        this.TypeChambres = res['data'];
        return this.TypeChambres;
      }),
      catchError(this.handleError)
    );
  }

  // Table function start
  getTableList() {
    return this.http.get(url + 'api/taable/liste').pipe(
      map((res: any) => {
        this.Tables = res['data'];
        return this.Tables;
      }),
      catchError(this.handleError)
    );
  }

  NewTable(t: table) {
    return this.http.post(url + 'api/taable/create', { data: t }).pipe(
      map((res: any) => {
        this.Tables = res['data'];
        return this.Tables;
      }),
      catchError(this.handleError)
    );
  }

  UpdateTable(t: table) {
    return this.http.put(url + 'api/taable/update/' + t.idtable, { data: t }).pipe(
      map((res: any) => {
        this.Tables = res['data'];
        return this.Tables;
      }),
      catchError(this.handleError)
    );
  }

  // Client function start
  getClientL() {
    return this.http.get(url + 'api/client/liste').pipe(
      map((res: any) => {
        this.Clients = res['data'];
        return this.Clients;
      }),
      catchError(this.handleError)
    );
  }

  NewClient(c: Client) {
    return this.http.post(url + 'api/client/create', { data: c }).pipe(
      map((res: any) => {
        this.Clients = res['data'];
        return this.Clients;
      }),
      catchError(this.handleError)
    );
  }

  UpdateClient(c: Client) {
    return this.http.put(url + 'api/client/update/' + c.idclient, { data: c }).pipe(
      map((res: any) => {
        this.Clients = res['data'];
        return this.Clients;
      }),
      catchError(this.handleError)
    );
  }

  DeleteClient(c: Client) {
    return this.http.delete(url + 'api/client/delete' + c.idclient).pipe(
      map((res: any) => {
        this.Clients = res['data'];
        return this.Clients;
      }),
      catchError(this.handleError)
    );
  }

  // Charge function start
  getChargeL() {
    return this.http.get(url + 'api/charge/liste').pipe(
      map((res: any) => {
        this.Charges = res['data'];
        return this.Charges;
      }),
      catchError(this.handleError)
    );
  }

  NewCharge(c: Charge) {
    return this.http.post(url + 'api/charge/new', { data: c }).pipe(
      map((res: any) => {
        this.Charges = res['data'];
        return this.Charges;
      }),
      catchError(this.handleError)
    );
  }

  UpdateCharge(c: Charge) {
    return this.http.put(url + 'api/charge/update/' + c.idcharge, { data: c }).pipe(
      map((res: any) => {
        this.Charges = res['data'];
        return this.Charges;
      }),
      catchError(this.handleError)
    );
  }

  DeleteCharge(c: Charge) {
    return this.http.delete(url + 'api/charge/delete/' + c.idcharge).pipe(
      map((res: any) => {
        this.Charges = res['data'];
        return this.Charges;
      }),
      catchError(this.handleError)
    );
  }

  // Unite function start
  getUniteListe() {
    return this.http.get(url + 'api/unite/liste').pipe(
      map((res: any) => {
        this.Unites = res['data'];
        return this.Unites;
      }),
      catchError(this.handleError)
    );
  }

  newUnite(u: Unite) {
    return this.http.post(url + 'api/unite/create', { data: u }).pipe(
      map((res: any) => {
        this.Unites = res['data'];
        return this.Unites;
      }),
      catchError(this.handleError)
    );
  }

  UpdateUnite(u: Unite) {
    return this.http.put(url + 'api/unite/update/' + u.idunite, { data: u }).pipe(
      map((res: any) => {
        this.Unites = res['data'];
        return this.Unites;
      }),
      catchError(this.handleError)
    );
  }

  // Famille function start
  getFamilleListe() {
    return this.http.get(url + 'api/famille/liste').pipe(
      map((res: any) => {
        this.Familles = res['data'];
        return this.Familles;
      }),
      catchError(this.handleError)
    );
  }

  createFamille(f: Famille) {
    return this.http.post(url + 'api/famille/create', { data: f }).pipe(
      map((res: any) => {
        this.Familles = res['data'];
        return this.Familles;
      }), catchError(this.handleError)
    );
  }

  UpdateFamille(f: Famille) {
    return this.http.put(url + 'api/famille/update/' + f.idfamille, { data: f }).pipe(
      map((res: any) => {
        this.Familles = res['data'];
        return this.Familles;
      }), catchError(this.handleError)
    );
  }

  // Stock function start
  getStock() {
    return this.http.get(url + 'api/stock/liste').pipe(
      map((res: any) => {
        this.Stocks = res['data'];
        return this.Stocks;
      }),
      catchError(this.handleError)
    );
  }

  newStock(s: Stock) {
    return this.http.post(url + 'api/stock/create', { data: s }).pipe(
      map((res: any) => {
        this.Stocks = res['data'];
        return this.Stocks;
      }),
      catchError(this.handleError)
    );
  }

  updateStock(s: Stock) {
    return this.http.put(url + 'api/stock/update/' + s.idstock, { data: s }).pipe(
      map((res: any) => {
        this.Stocks = res['data'];
        return this.Stocks;
      }),
      catchError(this.handleError)
    );
  }

  DeleteStock(s: Stock) {
    return this.http.delete(url + 'api/stock/delete/' + s.idstock).pipe(
      map((res: any) => {
        this.Stocks = res['data'];
        return this.Stocks;
      }),
      catchError(this.handleError)
    );
  }

  CreateIngredient(i:Ingredient){
    return this.http.post(url + 'api/ingredient/create', {data:i}).pipe(
      map((res:any)=>{
        this.Stocks = res['data'];
        return this.Stocks;
      }),
      catchError(this.handleError)
    );
  }

  DeleteIngredient(i:Ingredient){
    return this.http.delete(url + 'api/ingredient/delete/' + i.idingredient).pipe(
      map((res:any)=>{
        this.Stocks = res['data'];
        return this.Stocks;
      }),
      catchError(this.handleError)
    );
  }

  getAutreSL(){
    return this.http.get(url + 'api/autres/liste').pipe(
      map((res:any)=>{
        this.Autres = res['data'];
        return this.Autres;
      }),
      catchError(this.handleError)
    );
  }

  NewAutres(a:Autre){
    return this.http.post(url + 'api/autres/new', {data:a}).pipe(
      map((res:any)=>{
        this.Autres = res['data'];
        return this.Autres;
      }),
      catchError(this.handleError)
    );
  }

  UpdateAutres(a:Autre){
    return this.http.put(url + 'api/autres/update/' + a.idautres, {data:a}).pipe(
      map((res:any)=>{
        this.Autres = res['data'];
        return this.Autres;
      }),
      catchError(this.handleError)
    );
  }

  DeleteAutres(a:Autre){
    return this.http.delete(url + 'api/autres/delete/'+ a.idautres).pipe(
      map((res:any)=>{
        this.Autres = res['data'];
        return this.Autres;
      }),
      catchError(this.handleError)
    );
  }

  // Handle Error
  private handleError(error: HttpErrorResponse) {
    // return an observable with a user friendly message
    return throwError(error);
  }
}
