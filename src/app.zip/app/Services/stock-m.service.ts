import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, throwError } from 'rxjs';
import { Histostock } from '../Object/Histostock';
import { url } from '../Object/url';
import { DateToShortDate } from '../Object/function';
import { Entrestock } from '../Object/Entrestock';
import { Detaile } from '../Object/Detaile';
import { Histoinventaire } from '../Object/Histoinventaire';
import { Sortie } from '../Object/Sortie';
import { Details } from '../Object/Details';

@Injectable({
  providedIn: 'root'
})
export class StockMService {

  constructor(private http: HttpClient) { }

  HistoS:Histostock[] = [];
  HistoI:Histoinventaire[] = [];
  Sorties:Sortie[] = [];

  // getHistoStock list
  getHistoStockList(){
    return this.http.get(url + 'api/histostock/liste').pipe(
      map((res:any)=>{
        this.HistoS = res['data'];
        this.HistoS.forEach((item)=>{
          item.dateh = DateToShortDate(item.dateh);
        });
        return this.HistoS;
      }),
      catchError(this.handleError)
    );
  }
  
  // Entre stock 
  newEntrestock(e:Entrestock){
    return this.http.post(url + 'api/entrestock/new', {data:e}).pipe(
      map((res:any)=>{
        let r:Entrestock = res['data'];
        return r;
      }),
      catchError(this.handleError)
    );
  }
  
  newDetaile(d:Detaile){
    return this.http.post(url + 'api/detaile/new/'+ d.identree.identree, {data:d}).pipe(
      map((res:any)=>{
        let r = res['data'];
        return r;
      }),
      catchError(this.handleError)
    );
  }

  // Inventaire start

  getHistoInventaireL(){
    return this.http.get(url + 'api/histoinventaire/liste').pipe(
      map((res:any)=>{
        this.HistoI = res['data'];
        this.HistoI.forEach((item)=>{
          return item.datei = DateToShortDate(item.datei);
        });
        return this.HistoI;
      }),
      catchError(this.handleError)
    );
  }

  newHistoinventaire(h:Histoinventaire){
    return this.http.post(url + 'api/histoinventaire/new/' + h.idstock.idstock, {data:h}).pipe(
      map((res:any)=>{
        let r = res['data'];
        return r;
      }),
      catchError(this.handleError)
    );
  }

  getSortieListe(){
    return this.http.get(url + 'api/sortie/liste').pipe(
      map((res:any)=>{
        this.Sorties = res['data'];
        this.Sorties.forEach((item)=>{
          item.dates = DateToShortDate(item.dates);
        });
        return this.Sorties;
      }),
      catchError(this.handleError)
    );
  }

  NewSortie(s:Sortie){
    return this.http.post(url + 'api/sortie/new', {data:s}).pipe(
      map((res:any)=>{
        let r = res['data'];
        return r;
      }),
      catchError(this.handleError)
    );
  }

  NewDetails(d:Details){
    return this.http.post(url + 'api/details/new/'+ d.idsortie.idsortie, {data:d}).pipe(
      map((res:any)=>{
        let r = res['data'];
        return r;
      }),
      catchError(this.handleError)
    );
  }

  // Handle Error
  private handleError(error: HttpErrorResponse) {
    // return an observable with a user friendly message
    return throwError(error);
  }
}
