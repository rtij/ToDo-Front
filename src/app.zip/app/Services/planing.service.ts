import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, map, throwError } from 'rxjs';
import { Enregistrment } from '../Object/Enregistrement';
import { url } from '../Object/url';
import { DateToShortDate } from '../Object/function';
import { Planning } from '../Object/Planning';
import { Reservation } from '../Object/Reservation';
import { Detailreservation } from '../Object/Detailreservation';

@Injectable({
  providedIn: 'root'
})
export class PlaningService {

  constructor(private http: HttpClient) { }
  Registre: Enregistrment[] = [];
  Reservations: Reservation[] = [];
  Plannings: Planning[] = [];

  getReservationL() {
    return this.http.get(url + 'api/reservation/liste').pipe(
      map((res: any) => {
        this.Reservations = res['data'];
        this.Reservations.forEach((item) => {
          item.dater = DateToShortDate(item.dater);
        });
        return this.Reservations;
      }),
      catchError(this.handleError)
    );
  }

  NewReservation(r: Reservation) {
    return this.http.post(url + 'api/reservation/new', { data: r }).pipe(
      map((res: any) => {
        let r: Reservation = res['data'];
        r.dater = DateToShortDate(r.dater);
        return r;
      }),
      catchError(this.handleError)
    );
  }

  NewDetailR(d: Detailreservation) {
    return this.http.post(url + 'api/detailreservation/new/' + d.idreservation.idreservation, { data: d }).pipe(
      map((res: any) => {
        this.Reservations = res['data'];
        this.Reservations.forEach((item) => {
          item.dater = DateToShortDate(item.dater);
        });
        return this.Reservations;
      }
      ),
      catchError(this.handleError)
    )
  }

  UpdateResrvation(r: Reservation) {
    return this.http.put(url + 'api/reservation/update/' + r.idreservation, { data: r }).pipe(
      map((res: any) => {
        this.Reservations = res['data'];
        this.Reservations.forEach((item) => {
          item.dater = DateToShortDate(item.dater);
        });
        return this.Reservations;
      }),
      catchError(this.handleError)
    );
  }

  // 
  getPlanningsL() {
    return this.http.get(url + 'api/planning/liste').pipe(
      map((res: any) => {
        this.Plannings = res['data'];
        this.Plannings.forEach((item) => {
          item.datea = DateToShortDate(item.datea);
          item.dated = DateToShortDate(item.dated);
        });
        return this.Plannings;
      }),
      catchError(this.handleError)
    );
  }

  NewPlanning(p: Planning) {
    return this.http.post(url + 'api/planning/new', { data: p }).pipe(
      map((res: any) => {
        this.Plannings = res['data'];
        this.Plannings.forEach((item) => {
          item.datea = DateToShortDate(item.datea);
          item.dated = DateToShortDate(item.dated);
        });
        return this.Plannings;
      }),
      catchError(this.handleError)
    );
  }

  UpdatePlanning(p: Planning) {
    return this.http.put(url + 'api/planning/update/' + p.idplanning, { data: p }).pipe(
      map((res: any) => {
        this.Plannings = res['data'];
        this.Plannings.forEach((item) => {
          item.datea = DateToShortDate(item.datea);
          item.dated = DateToShortDate(item.dated);
        });
        return this.Plannings;
      }),
      catchError(this.handleError)
    );
  }

  getEnregistrementL() {
    return this.http.get(url + 'api/enregistrement/liste').pipe(
      map((res: any) => {
        this.Registre = res['data'];
        this.Registre.forEach((item) => {
          item.datea = DateToShortDate(item.datea);
          item.dated = DateToShortDate(item.dated);
        });
        return this.Registre;
      }),
      catchError(this.handleError)
    );
  }

  SaveEnregistrement(e: Enregistrment) {
    return this.http.post(url + 'api/enregistrement/new', { data: e }).pipe(
      map((res: any) => {
        this.Registre = res['data'];
        this.Registre.forEach((item) => {
          item.datea = DateToShortDate(item.datea);
          item.dated = DateToShortDate(item.dated);
        });
        return this.Registre;
      }),
      catchError(this.handleError)
    );
  }

  UpdateEnregistrement(e: Enregistrment) {
    return this.http.put(url + 'api/enregistrement/update/' + e.idenregistrement, { data: e }).pipe(
      map((res: any) => {
        this.Registre = res['data'];
        this.Registre.forEach((item) => {
          item.datea = DateToShortDate(item.datea);
          item.dated = DateToShortDate(item.dated);
        });
        return this.Registre;
      }),
      catchError(this.handleError)
    );
  }

  // Handle Error
  private handleError(error: HttpErrorResponse) {
    // return an observable with a user friendly message
    return throwError(error);
  }
}
