import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { LoginService } from '../Services/login.service';

@Component({
  selector: 'app-loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.css']
})
export class LoadingComponent {

  constructor(private l: LoadingBarService, private loginService: LoginService, private toastr: ToastrService, private router: Router) { }

  ngOnInit(): void {
    this.getUtilisateur();
  }
  type: string = "";
  loader = this.l.useRef();
  active: boolean = true;

  getUtilisateur() {
    this.loader.start();
    this.loginService.getutilisteur().subscribe(
      (res) => {
        this.loader.complete();
        this.type = res.attribution;
        localStorage.setItem('type', res.attribution);
        this.getRefresh();
      },
      (err) => {
        if (this.active) {
          this.loader.complete();
          this.getUtilisateur();
        }
      }
    );
  }

  getRefresh() {
    this.loader.start();
    if (this.loginService.getRefToken()) {
      this.Navigation();
      this.loader.complete();
    } else {
      this.loginService.getRefresh().subscribe(
        (res) => {
          this.loader.complete();
          if (res == "error") {
            this.loginService.removeData();
            this.router.navigate(['/Login']);
            this.toastr.warning("Ce compte n'existe plus");
          } else {
            localStorage.setItem('xauth', res);
            this.Navigation();
          }
        },
        (err) => {
          console.log(err.error);
          this.getRefresh();
        }
      );
    }
  }

  Navigation() {
    if (this.type == "Administrateur") {
      this.router.navigate(['/Administrateur']);
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
