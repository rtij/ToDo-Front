import { Stock } from "./Stock";

export class Ingredient{
    idproduit:Stock;
    idmatiere:Stock;
    qte:number;
    idingredient?:number;
    constructor(idproduit:Stock, idmatiere:Stock, qte:number){
        this.idproduit = idproduit;
        this.idmatiere = idmatiere;
        this.qte = qte;
    }
}