import { Autre } from "./Autres";
import { Reservation } from "./Reservation";

export class Detautre {
    montant: number;
    remise: number;
    tarif: number;
    idreservation: Reservation;
    idautres: Autre;
    nbr: number;
    duree:number;
    iddetautre?: number;
    constructor(idautres: Autre, nbr: number, idreservation: Reservation, remise: number, tarif: number, duree:number) {
        this.idautres = idautres;
        this.duree = duree;
        this.nbr = nbr;
        this.tarif = tarif;
        this.remise = remise;
        this.idreservation = idreservation;
        this.montant = (this.tarif * this.nbr) - this.remise;
    }
}