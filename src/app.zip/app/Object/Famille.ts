export class Famille{
    libelle:string;
    issup:boolean;
    idfamille?:number;
    constructor(libelle:string){
        this.libelle = libelle;
        this.issup = false;
    }
}