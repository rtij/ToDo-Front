
export class Utilisateur{
    issup:boolean = false;
    password:string;
    attribution:string;
    isonline:boolean = false;
    sideopen:boolean = true;
    username:string;
    idutilisateur?:number;
    constructor(username:string, password:string, attribution:string){
        this.username = username;
        this.password = password;
        this.attribution = attribution;
    }
}