import { Client } from "./Client";
import { Detailreservation } from "./Detailreservation";
import { Detautre } from "./Detautres";
import { detrestauration } from "./Detrestauration";
import { Planning } from "./Planning";
import { Utilisateur } from "./Utilisateur";

export class Reservation {
    titre: string;
    nbad: number;
    nbenf: number;
    color: string;
    dater: Date;
    state: boolean;
    idutilisateur: Utilisateur;
    idclient: Client;
    note: string;
    issup: boolean;
    nbchambre: number;
    nbsalle: number;
    avecp: boolean;
    idautreservice:Detautre[]= [];
    iddetrestauration:detrestauration[] = [];
    iddetailr:Detailreservation[] = [];
    idplanning:Planning[] = [];
    idreservation?: number;
    constructor(titre: string,
        nbad: number,
        nbenf: number,
        color: string,
        dateR: Date,
        state: boolean,
        idutilisateur: Utilisateur,
        idclient: Client,
        note: string,
        issup: boolean,
        nbchambre: number,
        nbsalle: number,
        avecp: boolean) {
        this.titre = titre;
        this.nbad = nbad;
        this.nbenf = nbenf;
        this.color = color;
        this.dater = dateR;
        this.state = state;
        this.idutilisateur = idutilisateur;
        this.idclient = idclient;
        this.note = note;
        this.issup = issup;
        this.nbchambre = nbchambre;
        this.nbsalle = nbsalle;
        this.avecp = avecp;
    }

}