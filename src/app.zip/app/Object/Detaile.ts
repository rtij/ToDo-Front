import { Entrestock } from "./Entrestock";
import { Stock } from "./Stock";

export class Detaile{
    idstock:Stock;
    qte:number;
    prixa:number;
    identree:Entrestock;
    iddetaile?:number;
    constructor(identree:Entrestock,idstock:Stock, qte:number, prixa:number){
        this.identree = identree;
        this.qte = qte;
        this.prixa = prixa;
        this.idstock = idstock;
    }
}