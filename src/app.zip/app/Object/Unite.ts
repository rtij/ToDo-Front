export class Unite{
    unite:string;
    idunite?:number;
    constructor(unite:string){
        this.unite = unite;
    }
}