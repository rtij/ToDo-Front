export class Typechambre{
    tarif:number = 0;
    typec:boolean = false;
    libelle:string="";
    idtypec?:number;
    issup:boolean = false;
    constructor(tarif:number, typec:boolean, libelle:string){
        this.tarif = tarif;
        this.typec = typec;
        this.libelle = libelle;
    }
}