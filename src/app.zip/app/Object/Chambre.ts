import { Typechambre } from "./Typechambre";

export class Chambre{
    idtypec:Typechambre;
    nbrp:number=0
    num:string = "";
    issup:boolean = false;
    idchambre?:number;
    constructor(idtypec:Typechambre, nbrp:number, num:string){
        this.idtypec = idtypec;
        this.nbrp = nbrp;
        this.num = num;
    }
}