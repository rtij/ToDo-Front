import { Reservation } from "./Reservation";
import { Restauration } from "./Restauration";

export class detrestauration {

    idrestauration: Restauration;
    idreservation: Reservation;
    nbr: number;
    remise:number;
    duree:number;
    montant: number;
    iddetrestauration?: number;
    constructor(idrestauration: Restauration,
        idreservation: Reservation,
        nbr: number,
        montant: number, remise:number, duree:number) {
        this.idreservation = idreservation;
        this.nbr = nbr;
        this.duree = duree;
        this.remise = remise;
        this.montant = montant;
        this.idrestauration = idrestauration;
    }
}