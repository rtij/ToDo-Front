import { Time } from "@angular/common";
import { Chambre } from "./Chambre";
import { Reservation } from "./Reservation";

export class Planning {
    dated: Date;
    datea: Date;
    heured: Time;
    heurea: Time;
    idchambre: Chambre;
    idreservation: Reservation;
    issup: boolean = false;
    idplanning?: number;
    constructor(dated: Date,
        datea: Date,
        heured: Time,
        heurea: Time,
        idchambre: Chambre,
        idreservation: Reservation,) {
        this.dated = dated;
        this.datea = datea;
        this.heurea = heurea;
        this.heured = heured;
        this.idchambre = idchambre;
        this.idreservation = idreservation;
    }
}