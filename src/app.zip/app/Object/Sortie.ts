export class Sortie{
    dates:Date;
    numbs:string;
    idsortie?:number;
    constructor(numbs:string, dates:Date){
        this.dates = dates;
        this.numbs = numbs;
    }
}