import { Typedepense } from "./Typedepense";
import { Utilisateur } from "./Utilisateur";

export class Depense{
    reference:string;
    libelle:string;
    montant:number;
    issup:boolean = false;
    idtyped:Typedepense;
    idutilisateur:Utilisateur;
    dated:Date;
    iddepense?:number;
    constructor(dated:Date, reference:string, libelle:string, montant:number, idtyped:Typedepense, idutilisateur:Utilisateur){
        this.reference  = reference;
        this.dated = dated;
        this.libelle = libelle;
        this.montant = montant;
        this.idtyped = idtyped;
        this.idutilisateur = idutilisateur;
    }
}