export class Typedepense{
    typedepense:string;
    idtyped?:number;
    constructor(typedepense:string){
        this.typedepense = typedepense;
    }
}