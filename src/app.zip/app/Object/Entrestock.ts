export class Entrestock{

    datee:Date;
    nume:string;
    identree?:number;
    constructor(datee:Date, nume:string){
        this.datee = datee;
        this.nume = nume;
    }
}