export class Charge {
    libelle: string;
    montant: number;
    idcharge?: number;
    constructor(libelle: string, montant: number) {
        this.libelle = libelle;
        this.montant = montant;
    }
}