import { Reservation } from "./Reservation";
import { Typechambre } from "./Typechambre";

export class Detailreservation{
    tarif:number;
    remise:number;
    mont:number;
    idtypec:Typechambre;
    puescompte:number;
    nbr:number;
    idreservation:Reservation;
    iddetailr?:number;
    constructor(tarif:number,
        remise:number,
        mont:number,
        idtypec:Typechambre,
        puescompte:number,
        nbr:number,
        idreservation:Reservation,){
        this.tarif = tarif;
        this.remise= remise;
        this.mont = mont;
        this.idtypec = idtypec;
        this.puescompte = puescompte;
        this.nbr = nbr;
        this.idreservation = idreservation;
    }
}