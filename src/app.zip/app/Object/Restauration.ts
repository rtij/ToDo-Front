export class Restauration{
    tarif:number = 0;
    libelle:string="";
    idrestauration?:number;
    issup:boolean = false;
    constructor(tarif:number, libelle:string){
        this.tarif = tarif;
        this.libelle = libelle;
    }
}