import { Stock } from "./Stock";

export class Histostock {
    idstock:Stock;
    libelle:string;
    entree:number;
    sortie:number;
    stock:number;
    dateh:Date;
    numbon: string;
    idhistostock?: number;
    constructor(numbon: string, idstock: Stock,stock:number, libelle: string, entree: number, sortie: number, dateh: Date) {
        this.idstock = idstock;
        this.libelle = libelle;
        this.stock = stock;
        this.entree = entree;
        this.sortie = sortie;
        this.dateh = dateh;
        this.numbon = numbon;
    }
}