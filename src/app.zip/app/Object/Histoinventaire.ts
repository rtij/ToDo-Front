import { Stock } from "./Stock";

export class Histoinventaire{

    datei:Date;
    qtet:number;
    qter:number;
    idstock:Stock;
    observation:string="";
    idhistoi?:number;
    constructor(qtet:number, qter:number, datei:Date, idstock:Stock, observation:string){
        this.datei = datei;
        this.observation = observation
        this.qter = qter;
        this.idstock = idstock;
        this.qtet = qtet;
    }
}