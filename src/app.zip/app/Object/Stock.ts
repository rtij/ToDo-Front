import { Famille } from "./Famille";
import { Ingredient } from "./Ingredient";
import { Unite } from "./Unite";

export class Stock {
    type: boolean;
    code: string;
    designation: string;
    qte: number;
    seuil: number;
    pra: number;
    pvu: number;
    idunite: Unite;
    idfamille: Famille;
    enstock:boolean;
    transformer: boolean;
    issup:boolean;
    idingredient:Ingredient[] = [];
    idstock?: number;
    constructor(type: boolean,enstock:boolean, code: string, designation: string, seuil: number, pra: number, pvu: number, idunite: Unite, idfamille: Famille, transformer: boolean) {
        this.qte = 0;
        this.type = type;
        this.code = code;
        this.designation = designation;
        this.seuil = seuil;
        this.pra = pra;
        this.enstock = enstock;
        this.pvu = pvu;
        this.idfamille = idfamille;
        this.idunite = idunite;
        this.transformer = transformer;
        this.issup = false;
        this.idingredient = [];
    }
}