import { attributeToDisplay } from "./ORM/orm";

export class Client {
    @attributeToDisplay()
    nom: string;
    @attributeToDisplay()
    adresse: string;
    @attributeToDisplay()
    email: string;
    tel: string;
    agence: boolean;
    issup: boolean;
    cin: string;
    nationalite: string;
    emailag: string
    agent: string;
    compte: number;
    nif: string;
    stat: string;
    rc: string;
    fidele: boolean;

    idclient?: number;
    constructor(nom: string, adresse: string, email: string, tel: string, nationalite: string, agence: boolean,emailag:string, cin: string, agent: string, nif: string, stat: string, rc: string) {
        this.nom = nom;
        this.adresse = adresse;
        this.email = email;
        this.tel = tel;
        this.nationalite = nationalite;
        this.cin = cin;
        this.agent = agent;
        this.emailag = emailag;
        this.nif = nif;
        this.stat = stat;
        this.rc = rc;
        this.agence = agence;
        this.fidele = false;
        this.issup = false;
        this.compte = 0;
    }
}