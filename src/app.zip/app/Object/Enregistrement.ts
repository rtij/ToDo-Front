import { Chambre } from "./Chambre";

export class Enregistrment {
    nomprenom: string;
    daten: Date;
    cin: string;
    nationalite: string;
    profession: string;
    adresse: string;
    venantd: string;
    allanta: string;
    duree: number;
    datea: Date;
    dated: Date;
    validitev: string;
    lieun: string;
    idchambre: Chambre;
    idenregistrement?: number;
    constructor(
        nomprenom: string,
        daten: Date,
        cin: string,
        nationalite: string,
        profession: string,
        adresse: string,
        venantd: string,
        allanta: string,
        duree: number,
        datea: Date,
        dated: Date,
        validaatev: string,
        lieun: string,
        idchambre: Chambre) {
        this.nomprenom = nomprenom;
        this.daten = daten;
        this.cin = cin;
        this.nationalite = nationalite;
        this.profession = profession;
        this.adresse = adresse;
        this.venantd = venantd;
        this.allanta = allanta
        this.duree = duree;
        this.datea = datea;
        this.dated = dated;
        this.validitev = validaatev;
        this.lieun = lieun
        this.idchambre = idchambre;
    }
}