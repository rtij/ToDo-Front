export class Autre{
    libelle:string;
    issup:boolean = false;
    tarif:number;
    idautres?:number;
    constructor(libelle:string, tarif:number){
        this.libelle = libelle;
        this.tarif = tarif;
    }
}