import { Sortie } from "./Sortie";
import { Stock } from "./Stock";

export class Details {
    idstock: Stock;
    idsortie: Sortie;
    qte: number;
    affectation: string
    iddetails?: number;
    constructor(idstock: Stock, qte: number, idsortie: Sortie, affectation: string) {
        this.idsortie = idsortie;
        this.idstock = idstock;
        this.qte = qte;
        this.affectation = affectation;
    }
}