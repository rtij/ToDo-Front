export class table{
    
    num:string;
    idtable?:number;
    constructor(num:string){
        this.num = num;
    }
}