import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConciergeRoutingModule } from './concierge-routing.module';
import { ConciergeComponent } from './concierge.component';


@NgModule({
  declarations: [
    ConciergeComponent
  ],
  imports: [
    CommonModule,
    ConciergeRoutingModule
  ]
})
export class ConciergeModule { }
