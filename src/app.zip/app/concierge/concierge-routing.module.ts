import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConciergeComponent } from './concierge.component';

const routes: Routes = [{ path: '', component: ConciergeComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConciergeRoutingModule { }
