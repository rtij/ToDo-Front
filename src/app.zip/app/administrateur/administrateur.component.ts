import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { LoginService } from '../Services/login.service';
import { Utilisateur } from '../Object/Utilisateur';

@Component({
  selector: 'app-administrateur',
  templateUrl: './administrateur.component.html',
  styleUrls: ['./administrateur.component.css']
})
export class AdministrateurComponent implements OnInit {


  constructor(private router: Router, private LoginService: LoginService, private l: LoadingBarService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getUtilisateur();
  }
  loader = this.l.useRef();
  Utilisateur!: Utilisateur;
  // page state 
  active: boolean = true;
  // themes state
  dark:boolean = false;
  side:boolean = true;

  // Save sidebar state
  Side(){
    this.side = !this.side;
    this.LoginService.SetOpen(this.Utilisateur).subscribe(
      (res)=>{
        this.loader.complete();
      },
      (err)=>{
        if(this.active){
          this.Error(err);
        }
      }
    );
  }

  Logout() {
    this.loader.start();
    this.LoginService.Logout().subscribe(
      (res) => {
        this.loader.complete();
        this.LoginService.removeData();
        this.router.navigate(['/Login']);
      },
      (err) => {
        this.loader.complete();
        this.Error(err);
      }
    );
  }

  // getData function

  CheckUserType() {
    if (this.Utilisateur.attribution != "Administrateur") {
      this.Logout();
    }
    // check sidebar state
    // if(this.Utilisateur.sideopen != this.side){
    //   document.getElementById("Close")?.click();
    // }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }


  getUtilisateur() {
    let u = this.LoginService.Utilisateur;
    this.loader.start();
    if (u) {
      this.Utilisateur = u;
      this.loader.complete();
      this.CheckUserType();
    } else {
      this.LoginService.getutilisteur().subscribe(
        (res) => {
          this.Utilisateur = res;
          this.loader.complete();
          this.CheckUserType();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getUtilisateur();
          }
        });
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
