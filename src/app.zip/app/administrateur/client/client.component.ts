import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Client } from 'src/app/Object/Client';
import { Restauration } from 'src/app/Object/Restauration';
import { ServicesService } from 'src/app/Services/services.service';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {
  constructor(private Service: ServicesService, private toastr: ToastrService, private l: LoadingBarService) {
  }

  ngOnInit(): void {
    this.getClient();
    console.log(Object.getOwnPropertyNames(Client));
  }

  // page state
  active: boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  page:number = 1;
  Clients: Client[] = [];

  // forms state
  box: boolean = false;

  // forms variable
  SelectedC!: Client;
  nom: string = "";
  tel: string = "";
  email: string = "";
  adresse: string = "";
  nationalite: string = "";
  nomag: string = "";
  agence: boolean = false;
  emailag: string = "";
  nif: string = "";
  stat: string = "";
  rc: string = "";


  Close() {
    this.box = false;
    this.Reset();
  }

  New() {
    this.box = true;
    this.Reset();
  }

  Update() {
    if (!this.SelectedC) {
      this.toastr.warning("Veuillez selectionner l'élement à modifier");
    } else {
      this.box = true;
    }
  }

  Reset() {
    this.nom = '';
    this.SelectedC = this.n;
    this.email = "";
    this.nomag = "";
    this.tel = "";
    this.nationalite = "";
    if(this.agence){
      this.agence = false;
      this.nomag = "";
      this.emailag = "";
      this.nif = "" ;
      this.stat = "";
      this.rc = "";
    }
  }

  SelectClient(c: Client) {
    this.SelectedC = c;
    this.nom = c.nom;
    this.email = c.email;
    this.tel = c.tel;
    this.adresse = c.adresse;
    this.nationalite = c.nationalite;
    if(c.agence){
      this.nomag = c.agent;
      this.agence = c.agence;
      this.emailag = c.emailag;
      this.nif = c.nif ;
      this.stat = c.stat;
      this.rc = c.rc;
    }
  }

  Save() {
    if (!this.SelectedC) {
      this.NewClient();
    } else {
      this.UpdateClient();
    }
  }

  NewClient() {
    let c = new Client(this.nom, this.adresse, this.email, this.tel, this.nationalite, this.agence, this.emailag, "", this.nomag, this.nif, this.stat, this.rc);
    this.loader.start();
    this.onsend = true;
    this.Service.NewClient(c).subscribe(
      (res) => {
        this.onsend = false;
        this.Clients = res;
        this.Reset();
        this.box = false;
        this.toastr.success("Enregistrment  effectué");
        this.loader.complete();
      },
      (err) => {
        this.onsend = false;
        this.loader.complete();
        this.Error(err);
      }
    )
  }

  UpdateClient() {
    this.SelectedC.nom = this.nom;
    this.SelectedC.adresse = this.adresse;
    this.SelectedC.email = this.email;
    this.SelectedC.nationalite = this.nationalite;
    this.SelectedC.tel = this.tel;
    this.SelectedC.agence = this.agence;
    if (this.agence) {
      this.SelectedC.emailag = this.emailag;
      this.SelectedC.nif = this.nif;
      this.SelectedC.stat = this.stat;
      this.SelectedC.rc = this.rc;
      this.SelectedC.agent = this.nomag;
    }
    this.loader.start();
    this.onsend = true;
    this.Service.UpdateClient(this.SelectedC).subscribe(
      (res)=>{
        this.Clients = res;
        this.toastr.success("Modification effectué");
        this.loader.complete();
        this.onsend = false;
        this.box = false;
      },
      (err)=>{
        this.Error(err);
        this.onsend = false;
      }
    )
  }



  DeleteClient() {
    if (!this.SelectedC) {
      this.toastr.warning("Veuillez selectionner le client à supprimer");
    } else {
      if (confirm("Voulez-vous vraiment supprimer cet(te) client ?")) {

      }
    }
  }

  // getData function
  getClient() {
    let c = this.Service.Clients;
    this.loader.start();
    if (c.length != 0) {
      this.Clients = c;
      this.loader.complete();
    } else {
      this.Service.getClientL().subscribe(
        (res) => {
          this.Clients = res;
          this.loader.complete();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getClient();
          }
        }
      )
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
