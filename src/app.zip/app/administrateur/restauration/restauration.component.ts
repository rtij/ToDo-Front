import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Restauration } from 'src/app/Object/Restauration';
import { table } from 'src/app/Object/tables';
import { ServicesService } from 'src/app/Services/services.service';

@Component({
  selector: 'app-restauration',
  templateUrl: './restauration.component.html',
  styleUrls: ['./restauration.component.css']
})
export class RestaurationComponent implements OnInit{
  constructor(private Service: ServicesService, private toastr: ToastrService, private l: LoadingBarService) {
  }

  ngOnInit(): void {
    this.getRestauration();
  }
  
  // page state
  active: boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  // Data
  Restaurations:Restauration[] = [];
  Tables:table[] = [];
  // forms state
  box: boolean = false;
  box1: boolean = false;

  // Typechambre variable
  tarif: number = 0;
  libelle: string = "";
  page: number = 1;

  // 
  SelectedR!: Restauration;
  
  // 
  Num:string="";
  SelectedT!:table;
  numt:string = "";

  SelectTable(t:table){
    this.SelectedT = t;
    this.numt = t.num;
  }

  Reset(){
    this.Num = "";
    this.numt= "";
    this.SelectedT = this.n;
  }

  UpdateTable(){
    if(this.numt != this.SelectedT.num){
      this.SelectedT.num = this.numt;
      this.loader.start();
      this.onsend = true;
      this.Service.UpdateTable(this.SelectedT).subscribe(
        (res)=>{
          this.Tables = res;
          this.Reset();
          this.onsend = false;
          this.loader.complete();
          this.toastr.success("Modification effectué")
        },
        (err)=>{
          this.Error(err);
          this.onsend = false;
        }
      );
    }else{
      this.Reset();
    }
  }

  SaveT(){
    let t = new table(this.Num);
    this.onsend = true;
    this.loader.start();
    this.Service.NewTable(t).subscribe(
      (res)=>{
        this.onsend = false;
        this.toastr.success("Enregistrement effectué");
        this.Tables = res;
        this.Reset();
      },
      (err)=>{
        this.loader.complete();
        this.onsend = false;
        this.Error(err);
      }
    )
  }


  // Restauration function
  Close() {
    this.box = false;
    this.ResetType();
  }

  New() {
    this.box = true;
    this.ResetType();
  }

  Update() {
    if (!this.SelectedR) {
      this.toastr.warning("Veuillez selectionner l'élement à modifier");
    } else {
      this.box = true;
    }
  }

  ResetType() {
    this.libelle = "";
    this.tarif = 0;
    this.SelectedR = this.n;
  }

  SelectType(r: Restauration) {
    this.SelectedR = r;
    this.libelle = r.libelle;
    this.tarif = r.tarif;
  }

  SaveR() {
    if (!this.SelectedR) {
      this.NewRestauration();
    } else {
      this.UpdateRestauration();
    }
  }

  DeleteRestauration() {
    if (!this.SelectedR) {
      this.toastr.warning("Veuillez selectionner l'élement à supprimer");
    } else {
      if (confirm("Voulez vous vraiment supprimer cette type de chambre")) {
        this.loader.start();
        this.Service.DeleteRestauration(this.SelectedR).subscribe(
          (res) => {
            this.loader.complete();
            this.Restaurations = res;
            this.toastr.success("Suupression effectué");
          },
          (err) => {
            this.loader.complete();
            this.Error(err);
            this.SelectedR.issup = true;
            this.UpdateRestauration();
          }
        )
      }
    }
  }

  UpdateRestauration() {
    this.SelectedR.libelle = this.libelle;
    this.SelectedR.tarif = this.tarif;
    this.loader.start();
    this.onsend = true;
    this.Service.UpdateRestauration(this.SelectedR).subscribe(
      (res) => {
        this.Restaurations = res;
        this.ResetType();
        this.box = false;
        this.loader.complete();
        this.onsend = false;
        this.toastr.success("Modification effectué");
      },
      (err) => {
        this.loader.complete();
        this.Error(err);
        this.onsend = false;
      }
    )
  }

  NewRestauration() {
    let r = new Restauration(this.tarif, this.libelle);
    this.loader.start();
    this.onsend = true;
    this.Service.NewRestauration(r).subscribe(
      (res) => {
        this.Restaurations = res;
        this.loader.complete();
        this.ResetType();
        this.box = false;
        this.onsend = false;
        this.toastr.success("Enregistrement effectué");
      },
      (err) => {
        this.Error(err);
        this.loader.complete();
        this.onsend = false;
      }
    )
  }

  // getData function
  getRestauration() {
    let t = this.Service.Restauration;
    this.loader.start();
    if (t.length != 0) {
      this.Restaurations = t;
      this.loader.complete();
      this.getTableL();
    } else {
      this.Service.getRestauration().subscribe(
        (res) => {
          this.Restaurations = res;
          this.loader.complete();
          this.getTableL();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getRestauration();
          }
        }
      )
    }
  }

  getTableL(){
    let t= this.Service.Tables;
    this.loader.start();
    if(t.length !=0 ){
      this.Tables = t;
      this.loader.complete();
    }else{
      this.Service.getTableList().subscribe(
        (res)=>{
          this.Tables = res;
          this.loader.complete();
        },
        (err)=>{
          this.loader.complete();
          if(this.active){
            this.Error(err);
            this.getTableL();
          }
        }
      )
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
