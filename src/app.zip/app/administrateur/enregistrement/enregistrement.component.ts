import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Chambre } from 'src/app/Object/Chambre';
import { Enregistrment } from 'src/app/Object/Enregistrement';
import { ServicesService } from 'src/app/Services/services.service';
import { StockMService } from 'src/app/Services/stock-m.service';

@Component({
  selector: 'app-enregistrement',
  templateUrl: './enregistrement.component.html',
  styleUrls: ['./enregistrement.component.css']
})
export class EnregistrementComponent implements OnInit {


  constructor(private Service: ServicesService, private stockmService: StockMService, private toastr: ToastrService, private l: LoadingBarService) {

  }

  ngOnInit(): void {
    this.getChambresL();
  }

  active: boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  page: number = 1;
  // Data
  Chambres:Chambre[] = [];
  Enregistrments: Enregistrment[] = [];
  Result: Enregistrment[] = [];
  // Filter variable
  date1!: Date;
  date2!: Date;
  // modal variable
  box: boolean = false;
  // 
  nomprenom: string = "";
  daten!: Date;
  cin: string = "";
  nationalite: string = "";
  profession: string = "";
  adresse: string = "";
  venantd: string = "";
  allanta: string = "";
  duree: number = 0;
  datea!: Date;
  dated!: Date;
  validitev: string = "";
  lieun: string = "";
  idchambre!: Chambre;
  numc:string="";

  // Forms function

  Save(){

  }

  FilterByDate() {
    if (this.date1 && this.date2) {

    } else {
      this.Result = this.Enregistrments;
    }
  }

  ShowModal() {
    this.box = true;
    this.Reset();
  }

  CloseModal() {
    this.box = false;
    this.Reset();
  }

  Reset() {
    this.nomprenom = "";
    this.daten = this.n;
    this.cin = "";
    this.nationalite = "";
    this.profession = "";
    this.adresse = "";
    this.venantd = "";
    this.allanta = "";
    this.duree = 0;
    this.numc = "";
    this.datea = this.n;
    this.dated = this.n;
    this.validitev = "";
    this.lieun = "";
    this.idchambre = this.n;
  }

  
  getChambresL() {
    let c = this.Service.Chambres;
    this.loader.start();
    if (c.length != 0) {
      this.Chambres = c;
      this.loader.complete();
    } else {
      this.Service.getChambreList().subscribe(
        (res) => {
          this.Chambres = res;
          this.loader.complete();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getChambresL();
          }
        }
      )
    }
  }

  
  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }

}
