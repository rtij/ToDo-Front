import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Chambre } from 'src/app/Object/Chambre';
import { Typechambre } from 'src/app/Object/Typechambre';
import { ServicesService } from 'src/app/Services/services.service';

@Component({
  selector: 'app-typechambre',
  templateUrl: './typechambre.component.html',
  styleUrls: ['./typechambre.component.css']
})
export class TypechambreComponent implements OnInit {

  constructor(private Service: ServicesService, private toastr: ToastrService, private l: LoadingBarService) {
  }

  ngOnInit(): void {
    this.getTypechambre();
  }

  // page state
  active: boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  // Data
  Chambres: Chambre[] = [];
  Typechambres: Typechambre[] = [];

  // forms state
  box: boolean = false;
  box1: boolean = false;

  // 
  SelectedC!: Chambre;
  SelectedT!: Typechambre;

  // Typechambre variable
  tarif: number = 0;
  typec: boolean = false;
  libelle: string = "";
  page: number = 1;

  // Chambre variable
  nbrp: number = 0;
  num: string = "";
  Typec!: Typechambre;
  nomt: string = "";
  page1: number = 1;

  // chambre forms function
  FindNumC() {
    let r = this.Chambres.find((item) => {
      return item.num == this.num;
    });
    if(r && this.SelectedC == r){
      return false;
    }else if (r) {
      return true;
    }
    return false;
  }

  NewC() {
    this.box1 = true;
    this.ResetC();
  }

  UpdateC() {
    if (!this.SelectedC) {
      this.toastr.warning("Veuillez selectionner l'lement à modifier");
    } else {
      this.box1 = true;
    }
  }

  ResetC() {
    this.num = "";
    this.nbrp = 0;
    this.nomt = "";
    this.Typec = this.n;
    this.SelectedC = this.n;
  }

  SelectC(c: Chambre) {
    this.SelectedC = c;
    this.num = c.num;
    this.nbrp = c.nbrp;
    this.Typec = c.idtypec;
    this.nomt = c.idtypec.libelle;
  }

  CloseC() {
    this.box1 = false;
    this.ResetC();
  }

  SaveC() {
    if (!this.SelectedC) {
      this.NewChambre();
    } else {
      this.UpdateChambre();
    }
  }

  findTypec() {
    let r = this.Typechambres.find((item) => {
      return item.libelle == this.nomt;
    });
    if (r) {
      this.Typec = r;
    } else {
      this.Typec = this.n;
      this.toastr.warning("not found");
    }
  }

  DeleteChambre() {
    if (!this.SelectedC) {
      this.toastr.warning("Veuillez selectionner l'élement à suuprimer")
    } else {
      if (confirm("Voulez vous vraiment supprimer cette chambre")) {
        this.Service.DeleteChambre(this.SelectedC).subscribe(
          (res) => {
            this.Chambres = res;
            this.toastr.success("Suppression effectué");
            this.loader.complete();
          },
          (err) => {
            this.loader.complete();
            this.Error(err);
            this.onsend = false;
          }
        );
      }
    }
  }

  UpdateChambre() {
    this.SelectedC.num = this.num;
    this.SelectedC.nbrp = this.nbrp;
    this.SelectedC.idtypec = this.Typec;
    this.loader.start();
    this.Service.UpdateChambre(this.SelectedC).subscribe(
      (res) => {
        this.Chambres = res;
        this.ResetC();
        this.box1 = false;
        this.toastr.success("Modification effectué");
        this.loader.complete();
      },
      (err) => {
        this.loader.complete();
        this.Error(err);
        this.onsend = false;
      }
    );
  }

  NewChambre() {
    let c = new Chambre(this.Typec, this.nbrp, this.num);
    this.loader.start();
    this.onsend = true;
    this.Service.createChambre(c).subscribe(
      (res) => {
        this.Chambres = res;
        this.ResetC();
        this.box1 = false;
        this.loader.complete();
        this.toastr.success("Enregistrment effectué");
      },
      (err) => {
        this.loader.complete();
        this.onsend = false;
        this.Error(err);
      }
    );
  }


  // typechambre forms function
  FindTypeC() {
    let r = this.Typechambres.find((item) => {
      return item.libelle == this.libelle;
    });
    if (r) {
      return true;
    }
    return false;
  }


  Close() {
    this.box = false;
    this.ResetType();
  }

  New() {
    this.box = true;
    this.ResetType();
  }

  Update() {
    if (!this.SelectedT) {
      this.toastr.warning("Veuillez selectionner l'élement à modifier");
    } else {
      this.box = true;
    }
  }

  ResetType() {
    this.libelle = "";
    this.tarif = 0;
    this.typec = false;
    this.SelectedT = this.n;
  }

  SelectType(t: Typechambre) {
    this.SelectedT = t;
    this.libelle = t.libelle;
    this.tarif = t.tarif;
    this.typec = t.typec;
  }

  SaveType() {
    if (!this.SelectedT) {
      this.NewTypechambre();
    } else {
      this.UpdateTypechambre();
    }
  }

  DeleteTypechambre() {
    if (!this.SelectedT) {
      this.toastr.warning("Veuillez selectionner l'élement à supprimer");
    } else {
      if (confirm("Voulez vous vraiment supprimer cette type de chambre")) {
        this.loader.start();
        this.Service.DeleteTypeChambre(this.SelectedT).subscribe(
          (res) => {
            this.loader.complete();
            this.Typechambres = res;
            this.toastr.success("Suupression effectué");
          },
          (err) => {
            this.loader.complete();
            this.Error(err);
            this.SelectedT.issup = true;
            this.UpdateTypechambre();
          }
        );
      }
    }
  }

  UpdateTypechambre() {
    this.SelectedT.libelle = this.libelle;
    this.SelectedT.tarif = this.tarif;
    this.SelectedT.typec = this.typec;
    this.loader.start();
    this.onsend = true;
    this.Service.UpdateTypeChambre(this.SelectedT).subscribe(
      (res) => {
        this.Typechambres = res;
        this.ResetType();
        this.loader.complete();
        this.onsend = false;
        this.box = false;
        this.toastr.success("Modification effectué");
      },
      (err) => {
        this.loader.complete();
        this.Error(err);
        this.onsend = false;
      }
    );
  }

  NewTypechambre() {
    let t = new Typechambre(this.tarif, this.typec, this.libelle);
    this.loader.start();
    this.onsend = true;
    this.Service.NewTypeChambre(t).subscribe(
      (res) => {
        this.Typechambres = res;
        this.loader.complete();
        this.ResetType();
        this.box = false;
        this.onsend = false;
        this.toastr.success("Enregistrement effectué");
      },
      (err) => {
        this.Error(err);
        this.loader.complete();
        this.onsend = false;
      }
    );
  }

  // getData function
  getTypechambre() {
    let t = this.Service.TypeChambres;
    this.loader.start();
    if (t.length != 0) {
      this.Typechambres = t;
      this.loader.complete();
      this.getChambresL();
    } else {
      this.Service.getTypechambreL().subscribe(
        (res) => {
          this.Typechambres = res;
          this.loader.complete();
          this.getChambresL();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getTypechambre();
          }
        }
      );
    }
  }

  getChambresL() {
    let c = this.Service.Chambres;
    this.loader.start();
    if (c.length != 0) {
      this.Chambres = c;
      this.loader.complete();
    } else {
      this.Service.getChambreList().subscribe(
        (res) => {
          this.Chambres = res;
          this.loader.complete();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getChambresL();
          }
        }
      );
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }

}
