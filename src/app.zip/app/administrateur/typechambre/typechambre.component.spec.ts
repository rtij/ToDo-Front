import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TypechambreComponent } from './typechambre.component';

describe('TypechambreComponent', () => {
  let component: TypechambreComponent;
  let fixture: ComponentFixture<TypechambreComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TypechambreComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TypechambreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
