import { Component } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Utilisateur } from 'src/app/Object/Utilisateur';
import { ServicesService } from 'src/app/Services/services.service';

@Component({
  selector: 'app-utilisateur',
  templateUrl: './utilisateur.component.html',
  styleUrls: ['./utilisateur.component.css']
})
export class UtilisateurComponent {

  constructor(private Service: ServicesService, private toastr: ToastrService, private l: LoadingBarService) {

  }

  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.getUtilisateur();
  }
  // page state
  active:boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  Utilisateurs: Utilisateur[] = [];
  search: string = '';
  box: boolean = false;
  n: any = null;
  modifp: boolean = false;
  page:number=1;

  username: string = "";
  password: string = "";
  confp: string = "";
  attribution: string = "";
  SelectedU!: Utilisateur;

  Reset() {
    this.username = "";
    this.password = "";
    this.attribution = "";
    this.confp = "";
    this.SelectedU = this.n;
  }

  New() {
    this.box = true;
    this.modifp = true;
    this.Reset();
  }

  Close() {
    this.box = false;
    this.Reset();
  }

  SelectU(u: Utilisateur) {
    this.SelectedU = u;
    this.username = u.username;
    this.attribution = u.attribution;
    this.modifp = false;
  }

  Modifp() {
    this.modifp = true;
  }

  Modify() {
    if (!this.SelectedU) {
      this.toastr.warning("Veuillez selectionné un utilisateur");
    } else {
      this.box = true;
      this.modifp = false;
    }
  }

  Save() {
    if (!this.SelectedU) {
      this.NewUtilisateur();
    } else {
      this.UpdateUtilisateur();
    }
  }

  NewUtilisateur() {
    let u = new Utilisateur(this.username, this.password, this.attribution);
    this.loader.start();
    this.onsend = true;
    this.Service.newUtilisateur(u).subscribe(
      (res) => {
        this.toastr.success("Enregistrement effectuer");
        this.Utilisateurs = res;
        this.box = false;
        this.loader.complete();
        this.Reset();
      },
      (err) => {
        console.log(err.error);
        this.toastr.warning("Server error");
        this.onsend = false;
        this.loader.complete();
      }
    );
  }

  UpdateUtilisateur() {
    this.SelectedU.username = this.username;
    this.SelectedU.attribution = this.attribution;
    if (this.modifp) {
      this.SelectedU.password = this.password;
    } else {
      this.SelectedU.password = this.n;
    }
    this.loader.start();
    this.onsend = true;
    this.Service.UpdateUtilisateur(this.SelectedU).subscribe(
      (res) => {
        this.Utilisateurs = res;
        this.onsend = false;
        this.toastr.success("Modification effectuer");
        this.loader.complete();
        this.box = false;
        this.Reset();
      },
      (err) => {
        console.log(err.error);
        this.toastr.warning("Server error");
        this.onsend = false;
        this.loader.complete();
        this.UpdateUtilisateur();
      }
    )
  }

  DeleteUtilisateur() {
    if (!this.SelectedU) {
      this.toastr.warning("Veuillez selectionné un utilisateur");
    } else {
      if (confirm("Voulez-vous vraiment supprimer cet utilisateur ?")) {
        this.loader.start();
        this.onsend = true;
        this.Service.DeleteUtilisateur(this.SelectedU).subscribe(
          (res) => {
            this.onsend = false;
            this.Utilisateurs = res;
            this.toastr.success("Suppréssion effectuer");
            this.loader.complete();
            this.Reset();
          },
          (err) => {
            this.Error(err);
            this.toastr.warning("Server error");
            this.loader.complete();
            this.SelectedU.issup = true;
            this.UpdateUtilisateur();
          }
        );
      }
    }
  }

  getUtilisateur() {
    this.loader.start();
    let l = this.Service.Utilisateurs;
    if (l.length != 0) {
      this.loader.complete();
      this.Utilisateurs = l;
    } else {
      this.Service.getUtilisateurL().subscribe(
        (res) => {
          this.Utilisateurs = res;
          this.loader.complete();
        },
        (err) => {
          this.loader.complete();
          if(this.active){
            this.Error(err);
            this.getUtilisateur();
          }
        }
      )
    }
  }

  
  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }
  
  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active= false;
  }
}
