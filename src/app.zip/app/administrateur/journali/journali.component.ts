import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Histoinventaire } from 'src/app/Object/Histoinventaire';
import { Stock } from 'src/app/Object/Stock';
import { ServicesService } from 'src/app/Services/services.service';
import { StockMService } from 'src/app/Services/stock-m.service';

@Component({
  selector: 'app-journali',
  templateUrl: './journali.component.html',
  styleUrls: ['./journali.component.css']
})
export class JournaliComponent implements OnInit {

  constructor(private Service: ServicesService, private stockmService: StockMService, private toastr: ToastrService, private l: LoadingBarService) {

  }

  
  ngOnInit(): void {
    this.getHistoI();
  }


  HistoI: Histoinventaire[] = [];

  // page state
  active: boolean = true;

  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  page: number = 1;

  // data
  noms: string = "";
  Stocks: Stock[] = [];
  Result: Histoinventaire[] = [];
  // Search variable
  SelectedS!: Stock;
  date1!: Date;
  date2!: Date;


  // Filter
  FilterByDate() {
    if (this.date1 && this.date2) {
      this.Result = this.HistoI.filter((item) => {
        return new Date(this.date1) <= new Date(item.datei) && new Date(this.date2) >= new Date(item.datei);
      });
    } else {
      this.Result = this.HistoI;
    }
  }

  // getData function
  getHistoI(){
    let h = this.stockmService.HistoI;
    this.loader.start();
    if(h.length != 0){
      this.HistoI = h;
      this.Result = h;
      this.loader.complete();
    }else{
      this.stockmService.getHistoInventaireL().subscribe(
        (res)=>{
          this.HistoI = res;
          this.Result = res;
          this.loader.complete();
        },
        (err)=>{
          this.loader.complete();
          if(this.active){
            this.Error(err);
          }
        }
      )
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
