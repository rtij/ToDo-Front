import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JournaliComponent } from './journali.component';

describe('JournaliComponent', () => {
  let component: JournaliComponent;
  let fixture: ComponentFixture<JournaliComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JournaliComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(JournaliComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
