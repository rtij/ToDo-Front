import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Charge } from 'src/app/Object/Charge';
import { Depense } from 'src/app/Object/Depense';
import { Typedepense } from 'src/app/Object/Typedepense';
import { Utilisateur } from 'src/app/Object/Utilisateur';
import { LoginService } from 'src/app/Services/login.service';
import { ServicesService } from 'src/app/Services/services.service';

@Component({
  selector: 'app-charge',
  templateUrl: './charge.component.html',
  styleUrls: ['./charge.component.css']
})
export class ChargeComponent implements OnInit {

  constructor(private Service: ServicesService, private toastr: ToastrService, private l: LoadingBarService, private LoginService: LoginService) {
  }

  ngOnInit(): void {
    this.getUtilisateur();
  }

  // component state
  active: boolean = true;

  loader = this.l.useRef();
  onsend: boolean = false;
  Utilisateur!: Utilisateur;

  // Data
  Charges: Charge[] = [];
  Typedepense: Typedepense[] = [];
  page: number = 1;

  // form state
  box1: boolean = false;
  box: boolean = false;

  // Forms variable
  SelectedC!: Charge;
  libelle: string = "";
  montant: number = 0;
  ref: string = "";
  n: any = null;

  // classification
  classD:string="";
  SelectedT!: Typedepense;

  // Depense function
  FindTyped(){
    let r = this.Typedepense.find((item)=>{
      return item.typedepense == this.classD;
    });
    if(r){
      this.SelectedT = r;
    }else{
      this.SelectedT = this.n;
    }
  }

  CloseD(){
    this.box1 = false;
    this.Reset();
  }

  SaveDepense(){
    let d = new Depense(new Date(),"", this.libelle, this.montant, this.SelectedT,this.Utilisateur);
    this.loader.start();
    this.onsend = true;
    this.Service.NewDepense(d).subscribe(
      (res) => {
        this.loader.complete();
        this.Reset();
        this.box1 = false;
        this.onsend = false;
        this.toastr.success("Enregistrement effectué");
      },
      (err) => {
        this.loader.complete();
        this.onsend = false;
        this.Error(err);
        this.toastr.warning("Server error");
      }
    );
  }

  NewDepense() {
    if(!this.SelectedC){
      this.toastr.warning("Selectionner la charge à ajouter");
    }else{
      this.box1 = true;
    }
  }


  // 

  New() {
    this.box = true;
    this.Reset();
  }

  Update() {
    if (!this.SelectedC) {
      this.toastr.warning("Veuillez selectionner l'lement à modifier");
    } else {
      this.box = true;
    }
  }

  Reset() {
    this.libelle = "";
    this.montant = 0;
    this.SelectedC = this.n;
    this.SelectedT = this.n;
  }

  Close() {
    this.box = false;
    this.Reset();
  }

  SelectC(c: Charge) {
    this.SelectedC = c;
    this.libelle = c.libelle;
    this.montant = c.montant;
  }


  Save() {
    if (!this.SelectedC) {
      this.CreateCharge();
    } else {
      this.UpdateCharge();
    }
  }

  CreateCharge() {
    let c = new Charge(this.libelle, this.montant);
    this.loader.start();
    this.onsend = true;
    this.Service.NewCharge(c).subscribe(
      (res) => {
        this.Charges = res;
        this.loader.complete();
        this.Reset();
        this.box = false;
        this.onsend = false;
        this.toastr.success("Enregistrement effectué");
      },
      (err) => {
        this.loader.complete();
        this.onsend = false;
        this.Error(err);
        this.toastr.warning("Server error");
      }
    );
  }

  UpdateCharge() {
    this.SelectedC.libelle = this.libelle;
    this.SelectedC.montant = this.montant;
    this.loader.start();
    this.Service.UpdateCharge(this.SelectedC).subscribe(
      (res) => {
        this.Charges = res;
        this.loader.complete();
        this.Reset();
        this.box = false;
        this.onsend = false;
        this.toastr.success("Enregistrement effectué");
      },
      (err) => {
        this.loader.complete();
        this.Error(err);
        this.toastr.warning("Server error");
      }
    );
  }


  DeleteCharge() {
    if (!this.SelectedC) {
      this.toastr.warning("Veuillez selectionné l'élement à supprimer");
    } else {
      if (confirm("Voulez vous vraiment supprimer cette dépense ?")) {
        this.loader.start();
        this.Service.DeleteCharge(this.SelectedC).subscribe(
          (res) => {
            this.Charges = res;
            this.loader.complete();
            this.Reset();
            this.onsend = false;
            this.toastr.success("Suppréssion effectué");
          },
          (err) => {
            this.loader.complete();
            this.Error(err);
            this.toastr.warning("Server error");
          }
        )
      }
    }
  }

  // getData function*
  getUtilisateur() {
    let u = this.LoginService.Utilisateur;
    this.loader.start();
    if (u) {
      this.Utilisateur = u;
      this.loader.complete();
      this.getCharge();
    } else {
      this.LoginService.getutilisteur().subscribe(
        (res) => {
          this.Utilisateur = res;
          this.loader.complete();
          this.getCharge();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getUtilisateur();
          }
        });
    }
  }

  getCharge() {
    let c = this.Service.Charges;
    this.loader.start();
    if (c.length != 0) {
      this.Charges = c;
      this.loader.complete();
      this.getTypedepense();
    } else {
      this.Service.getChargeL().subscribe(
        (res) => {
          this.Charges = res;
          this.loader.complete();
          this.getTypedepense();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getCharge();
          }
        }
      );
    }
  }

  getTypedepense() {
    let t = this.Service.Typedepenses;
    this.loader.start();
    if (t.length != 0) {
      this.Typedepense = t;
      this.loader.complete();
    } else {
      this.Service.getTypedepenseList().subscribe(
        (res) => {
          this.Typedepense = res;
          this.loader.complete();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getTypedepense();
          }
        }
      );
    }
  }


  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
