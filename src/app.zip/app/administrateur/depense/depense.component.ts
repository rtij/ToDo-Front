import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ColDef, ColumnApi, GridApi, GridReadyEvent, IDateFilterParams } from 'ag-grid-community';
import { ToastrService } from 'ngx-toastr';
import { Depense } from 'src/app/Object/Depense';
import { Typedepense } from 'src/app/Object/Typedepense';
import { Utilisateur } from 'src/app/Object/Utilisateur';
import { DateFormate } from 'src/app/Object/function';
import { LoginService } from 'src/app/Services/login.service';
import { ServicesService } from 'src/app/Services/services.service';
import { AG_GRID_LOCALE_FR } from 'src/app/local.fr';
 

@Component({
  selector: 'app-depense',
  templateUrl: './depense.component.html',
  styleUrls: ['./depense.component.css']
})
export class DepenseComponent implements OnInit {

  private gridApi!: GridApi<Depense>;

  constructor(private Service: ServicesService, private toastr: ToastrService, private l: LoadingBarService, private LoginService: LoginService) {
  }

  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.getUtilisateur();
  }

  // component state
  active: boolean = true;

  loader = this.l.useRef();
  onsend: boolean = false;
  // Data
  Depenses: Depense[] = [];
  Result: Depense[] = [];
  Utilisateur!: Utilisateur;
  Typedepense: Typedepense[] = [];
  page:number = 1;
  search:string="";

  // Search date
  date1!: Date;
  date2!: Date;

  // Forms variable
  classD:string="";
  SelectedD!: Depense;
  box: boolean = false;
  dated!: Date;
  libelle: string = "";
  montant: number = 0;
  ref: string = "";
  n: any = null;

  // modal variable
  modal: boolean = false;
  classification: string = "";
  SelectedT!: Typedepense;
  c: string = "";

  // ag-grid variable
  public rowSelection: 'single' | 'multiple' = 'single';
  private gridColumnApi!: ColumnApi;

  public columnDefs: ColDef[] = [
    {
      headerName: "Date", filter: 'agDateColumnFilter', sortable: true, valueGetter: (params) => {
        return this.FormateDate(params.data.dated)
      },
      filterParams: filterParams,
    },
    {field:"libelle", headerName:"Libellé", sortable:true, filter:true},
    {field:"idtyped.typedepense", headerName:"Classification", filter:true, sortable:true},
    {field:"reference", headerName:"Référence", sortable:true, filter:true},
    {field:"montant", headerName:"Montant", sortable:true, filter:false}
  ];
  
  public defaultColDef: ColDef = {
    flex: 1,
    minWidth: 200,
    resizable: true,
    filter: true,
    autoHeight: true,
    sortable: true,
    floatingFilter: true,
  };
  
  onGridReady(params: GridReadyEvent) {
    this.gridApi = params.api;
    this.gridColumnApi = params.columnApi;
    this.gridColumnApi.autoSizeAllColumns(false);
  }

  onSelectionChanged() {
    const selectedRows = this.gridApi.getSelectedRows();
    let id = selectedRows.length === 1 ? selectedRows[0].iddepense : null;
    if (id) {
      let e: any = this.Depenses.find((item) => {
        return item.iddepense == id;
      });
      this.SelectD(e);
    }
  }

  public localeText: {
    [key: string]: string;
  } = AG_GRID_LOCALE_FR;

  // Modal function
  ShowModal() {
    this.modal = true;
  }

  CloseModal() {
    this.modal = false;
  }

  SelectTypedepense(t: Typedepense) {
    this.SelectedT = t;
    this.c = t.typedepense;
  }


  NewClassification() {
    let t = new Typedepense(this.classification);
    this.loader.start();
    this.onsend = true;
    this.Service.newTypedepense(t).subscribe(
      (res) => {
        this.Typedepense = res;
        this.loader.complete();
        this.classification = "";
        this.onsend = false;
        this.toastr.success("Enregistrement effectué");
      },
      (err) => {
        this.Error(err);
        this.toastr.warning("Server error");
      }
    )
  }


  UpdateClassification() {
    this.loader.start();
    if (this.c != "") {
      this.SelectedT.typedepense = this.c;
      this.Service.updateTypedepense(this.SelectedT).subscribe(
        (res) => {
          this.Typedepense = res;
          this.toastr.success("Modification effectué");
          this.SelectedT = this.n;
          this.loader.complete();
        },
        (err) => {
          this.loader.complete();
          this.Error(err);
        }
      )
    } else {
      this.SelectedT = this.n;
      this.c = "";
    }
  }

  // Forms function

  FiilterByDate() {
    if (this.date1 && this.date2) {
      this.Result = this.Depenses.filter((item) => {
        return item.dated >= this.date1 && item.dated <= this.date2;
      });
    }
  }

  New() {
    this.box = true;
    this.Reset();
  }

  Reset() {
    this.ref = "";
    this.dated = this.n;
    this.libelle = "";
    this.montant = 0;
    this.SelectedD = this.n;
    this.classD = "";
  }

  Close() {
    this.box = false;
    this.Reset();
  }

  SelectD(d: Depense) {
    this.SelectedD = d;
    this.ref = d.reference;
    this.libelle = d.libelle;
    this.montant = d.montant;
    this.SelectedT = d.idtyped;
    this.dated = d.dated;
    this.classD = d.idtyped.typedepense;
  }

  Update(){
    if(!this.SelectedD){
      this.toastr.warning("Veuillez selectionner l'lement à modifier");
    }else{
      this.box = true;
    }
  }

  FindTyped(){
    let r = this.Typedepense.find((item)=>{
      return item.typedepense == this.classD;
    });
    if(r){
      this.SelectedT = r;
    }else{
      this.SelectedT = this.n;
    }
  }

  Save() {
    if (!this.SelectedD) {
      this.CreateDepense();
    }else{
      this.Updatedepense();
    }
  }

  CreateDepense() {
    if(!this.SelectedT){
      this.SelectedT = this.n;
    }
    let d = new Depense(this.dated, this.ref, this.libelle, this.montant, this.SelectedT, this.Utilisateur);
    this.loader.start();
    this.onsend = true;
    this.Service.NewDepense(d).subscribe(
      (res) => {
        this.Result = res;
        this.Depenses = res;
        this.loader.complete();
        this.Reset();
        this.box = false;
        this.onsend = false;
        this.toastr.success("Enregistrement effectuer");
      },
      (err) => {
        this.loader.complete();
        this.onsend = false;
        this.Error(err);
        this.toastr.warning("Server error");
      }
    );
  }

  Updatedepense() {
    this.SelectedD.dated = this.dated;
    this.SelectedD.libelle = this.libelle;
    this.SelectedD.montant = this.montant;
    this.SelectedD.reference = this.ref;
    this.SelectedD.idtyped = this.SelectedT;
    this.loader.start();
    this.Service.UpdateDepense(this.SelectedD).subscribe(
      (res) => {
        this.Result = res;
        this.Depenses = res;
        this.loader.complete();
        this.Reset();
        this.box = false;
        this.onsend = false;
        this.toastr.success("Enregistrement effectué");
      },
      (err) => {
        this.loader.complete();
        this.Error(err);
        this.toastr.warning("Server error");
      }
    );
  }

  DeleteDepense() {
    if (!this.SelectedD) {
      this.toastr.warning("Veuillez selectionné l'élement à supprimer");
    } else {
      if (confirm("Voulez vous vraiment supprimer cette dépense ?")) {
        this.loader.start();
        this.Service.DeleteDepense(this.SelectedD).subscribe(
          (res) => {
            this.Result = res;
            this.Depenses = res;
            this.loader.complete();
            this.Reset();
            this.onsend = false;
            this.toastr.success("Suppréssion effectué");
          },
          (err) => {
            this.loader.complete();
            this.Error(err);
            this.toastr.warning("Server error");
          }
        )
      }
    }
  }
  
  FormateDate(d: Date) {
    return DateFormate(d);
  }

  // get Data function
  getUtilisateur() {
    let u = this.LoginService.Utilisateur;
    this.loader.start();
    if (u) {
      this.Utilisateur = u;
      this.loader.complete();
      this.getTypedepense();
    } else {
      this.LoginService.getutilisteur().subscribe(
        (res) => {
          this.Utilisateur = res;
          this.loader.complete();
          this.getTypedepense();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getUtilisateur();
          }
        });
    }
  }

  getTypedepense() {
    let t = this.Service.Typedepenses;
    this.loader.start();
    if (t.length != 0) {
      this.Typedepense = t;
      this.loader.complete();
      this.getDepenseList();
    } else {
      this.Service.getTypedepenseList().subscribe(
        (res) => {
          this.Typedepense = res;
          this.loader.complete();
          this.getDepenseList();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getTypedepense();
          }
        }
      );
    }
  }

  getDepenseList() {
    let d = this.Service.Depenses;
    this.loader.start();
    if (d.length != 0) {
      this.Depenses = d;
      this.Result = d;
      this.loader.complete();
      this.gridColumnApi.autoSizeAllColumns(false);
    } else {
      this.Service.getDepenseList().subscribe(
        (res) => {
          this.Result = res;
          this.Depenses = res;
          this.loader.complete();
          this.gridColumnApi.autoSizeAllColumns(false);
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getDepenseList();
          }
        }
      );
    }
  }


  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }

}

var filterParams: IDateFilterParams = {
  comparator: (filterLocalDateAtMidnight: Date, cellValue: string) => {
    var dateAsString = cellValue;
    if (dateAsString == null) return -1;
    var dateParts = dateAsString.split('-');
    var cellDate = new Date(
      Number(dateParts[2]),
      Number(dateParts[1]) - 1,
      Number(dateParts[0])
    );
    if (filterLocalDateAtMidnight.getTime() === cellDate.getTime()) {
      return 0;
    }
    if (cellDate < filterLocalDateAtMidnight) {
      return -1;
    }
    if (cellDate > filterLocalDateAtMidnight) {
      return 1;
    }
    return 0;
  },
  inRangeFloatingFilterDateFormat: 'Do MMM YYYY',
};
