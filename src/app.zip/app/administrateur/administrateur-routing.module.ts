import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdministrateurComponent } from './administrateur.component';
import { ParamsComponent } from './params/params.component';
import { UtilisateurComponent } from './utilisateur/utilisateur.component';
import { DepenseComponent } from './depense/depense.component';
import { TypechambreComponent } from './typechambre/typechambre.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RestaurationComponent } from './restauration/restauration.component';
import { ClientComponent } from './client/client.component';
import { StockComponent } from './stock/stock.component';
import { PlaningComponent } from './planing/planing.component';
import { VenteComponent } from './vente/vente.component';
import { HistocomptecComponent } from './histocomptec/histocomptec.component';
import { PaiementComponent } from './paiement/paiement.component';
import { ChargeComponent } from './charge/charge.component';
import { ProduitComponent } from './produit/produit.component';
import { FicheComponent } from './fiche/fiche.component';
import { EntreesComponent } from './entrees/entrees.component';
import { SortiesComponent } from './sorties/sorties.component';
import { InventaireComponent } from './inventaire/inventaire.component';
import { HistoriqueSComponent } from './historique-s/historique-s.component';
import { JournalComponent } from './journal/journal.component';
import { JournaliComponent } from './journali/journali.component';
import { JournaleComponent } from './journale/journale.component';
import { JournalSComponent } from './journal-s/journal-s.component';
import { EnregistrementComponent } from './enregistrement/enregistrement.component';
import { PlanningFormComponent } from './planning-form/planning-form.component';
import { AutreComponent } from './autre/autre.component';
import { Utilisateur } from '../Object/Utilisateur';

const routes: Routes = [
  {
    path: '', component: AdministrateurComponent, children: [
      { path: 'Depense', component: DepenseComponent },
      { path: 'Depense/Charge', component: ChargeComponent },
      { path: 'Dashboard', component: DashboardComponent },
      {
        path: 'Clients', component: ClientComponent, children: [
          { path: '', redirectTo: 'Historiques', pathMatch: 'full' },
          { path: 'Historiques', component: HistocomptecComponent },
          { path: 'Paiements', component: PaiementComponent }
        ]
      },
      {
        path: 'Stocks', component: StockComponent, children: [
          { path: '', pathMatch: 'full', redirectTo: 'Produits' },
          { path: 'Produits', component: ProduitComponent },
          { path: 'Historiques', component: HistoriqueSComponent },
          { path: 'FicheTechnique', component: FicheComponent },
          { path: 'Produits/EntreeStock', component: EntreesComponent },
          { path: 'Produits/SortieStock', component: SortiesComponent },
          { path: 'Inventaire', component: InventaireComponent }
        ]
      },
      { path: 'Enregistrement', component: EnregistrementComponent },
      {
        path: 'Journals', component: JournalComponent, children: [
          { path: '', pathMatch: 'full', redirectTo: 'Inventaires' },
          { path: 'Inventaires', component: JournaliComponent },
          { path: 'Entrees', component: JournaleComponent },
          { path: 'Sorties', component: JournalSComponent }
        ]
      },
      {
        path: 'Planning', component: PlaningComponent
      },
      { path: 'Planning/Create', component: PlanningFormComponent },
      { path: 'Ventes', component: VenteComponent, 
        data:{ type: Utilisateur, instances: Utilisateur }
      },
      {
        path: 'Params', component: ParamsComponent, children: [
          { path: '', redirectTo: 'Utilisateurs', pathMatch: 'full' },
          { path: 'Restaurations', component: RestaurationComponent },
          { path: 'Utilisateurs', component: UtilisateurComponent },
          { path: 'Chambres', component: TypechambreComponent },
          { path: 'Autres', component: AutreComponent }
        ]
      }
    ]
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdministrateurRoutingModule { }
