import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Detaile } from 'src/app/Object/Detaile';
import { Entrestock } from 'src/app/Object/Entrestock';
import { Stock } from 'src/app/Object/Stock';
import { ServicesService } from 'src/app/Services/services.service';
import { StockMService } from 'src/app/Services/stock-m.service';

@Component({
  selector: 'app-entrees',
  templateUrl: './entrees.component.html',
  styleUrls: ['./entrees.component.css']
})
export class EntreesComponent implements OnInit {

  constructor(private Service: ServicesService, private StockmService: StockMService, private l: LoadingBarService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getStock();
  }

  // page state
  active: boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  page: number = 1;

  // Data
  Stocks: Stock[] = [];
  // Form variables
  dateE!: Date;
  index: number = 0;
  // 
  NumE: string = "";
  SelectedS!: Stock;
  qte: number = 0;
  code: string = "";
  designation: string = "";
  Detaile: Detaile[] = [];
  SelectedE!: Entrestock;

  FindStock(): boolean {
    let r = this.Stocks.find((item) => {
      return item.code == this.code;
    });
    if (r) {
      this.SelectedS = r;
      this.designation = r.designation;
      return true;
    } else {
      this.SelectedS = this.n;
      this.designation = "";
    }
    return false;
  }


  // Form function
  Remove(i: number) {
    this.Detaile.splice(i, 1);
  }

  AddDetaile() {
    if (!this.SelectedE) {
      this.SelectedE = new Entrestock(this.dateE, this.NumE);
    }
    this.Detaile.push(new Detaile(this.SelectedE, this.SelectedS, this.qte, this.SelectedS.pra));
    this.ResetSf();
  }

  ResetSf() {
    this.SelectedS = this.n;
    this.code = "";
    this.designation = "";
    this.qte = 0;
  }

  Reset() {
    this.NumE = "";
    this.Detaile = [];
    this.qte = 0;
    this.index = 0;
    this.dateE = this.n;
    this.SelectedS = this.n;
    this.SelectedE = this.n;
  }

  Save() {
    this.loader.start();
    this.onsend = true;
    this.StockmService.newEntrestock(this.SelectedE).subscribe(
      (res) => {
        this.SelectedE = res;
        this.loader.complete();
        this.SaveDetaile();
      },
      (err) => {
        this.loader.complete();
        this.onsend = false;
        if (this.active) {
          this.Error(err);
        }
      }
    );
  }

  SaveDetaile() {
    if (this.index < this.Detaile.length) {
      this.loader.start();
      this.Detaile[this.index].identree = this.SelectedE;
      this.StockmService.newDetaile(this.Detaile[this.index]).subscribe(
        (res) => {
          this.Stocks = res;
          this.Service.Stocks = res;
          this.FilterStock();
          this.loader.complete();
          this.index = this.index + 1;
          this.SaveDetaile();
        },
        (err) => {
          this.loader.complete();
          this.onsend = false;
          if (this.active) {
            this.Error(err);
          }
        }
      );
    } else {
      this.Reset();
      this.toastr.success("Enregistrement effectué");
    }
  }

  // FilterData
  FilterStock() {
    this.Stocks = this.Stocks.filter((item) => {
      return item.enstock == true;
    });
  }

  // getData function
  getStock() {
    let s = this.Service.Stocks;
    this.loader.start();
    if (s.length != 0) {
      this.Stocks = s;
      this.loader.complete();
      this.FilterStock();
    } else {
      this.Service.getStock().subscribe(
        (res) => {
          this.Stocks = res;
          this.loader.complete();
          this.FilterStock();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getStock();
          }
        }
      )
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }


  ngOnDestroy() {
    this.active = false;
  }
}
