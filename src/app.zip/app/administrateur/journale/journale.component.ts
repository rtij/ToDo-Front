import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { LoadingCellRenderer } from 'ag-grid-community/dist/lib/rendering/cellRenderers/loadingCellRenderer';
import { ToastrService } from 'ngx-toastr';
import { Histostock } from 'src/app/Object/Histostock';
import { ServicesService } from 'src/app/Services/services.service';
import { StockMService } from 'src/app/Services/stock-m.service';

@Component({
  selector: 'app-journale',
  templateUrl: './journale.component.html',
  styleUrls: ['./journale.component.css']
})
export class JournaleComponent implements OnInit {

  constructor(private Service: ServicesService, private stockmService: StockMService, private toastr: ToastrService, private l: LoadingBarService) {

  }

  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.getHistoStock();
  }

  // page state
  active: boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  page: number = 1;
  // Data
  HistoStocks: Histostock[] = [];
  Result: Histostock[] = [];
  // 
  date1!:Date;
  date2!:Date;


  // Filter
  FilterByDate(){
    if(this.date1 && this.date2){

    }else{
      this.Result = this.HistoStocks;
    }
  }

  // get Data function
  getHistoStock() {
    let h = this.stockmService.HistoS;
    this.loader.start();
    let f = ()=>{
      this.HistoStocks = this.HistoStocks.filter((item)=>{
        return item.entree > 0;
      });
    }
    if (h.length != 0) {
      this.HistoStocks = h;
      f();
      this.Result = this.HistoStocks;
      this.loader.complete();
    } else {
      this.stockmService.getHistoStockList().subscribe(
        (res) => {
          this.HistoStocks = res;
          f();
          this.Result = this.HistoStocks;
          this.loader.complete();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
          }
        }
      );
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }


  ngOnDestroy() {
    this.active = false;
  }

}
