import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Autre } from 'src/app/Object/Autres';
import { ServicesService } from 'src/app/Services/services.service';

@Component({
  selector: 'app-autre',
  templateUrl: './autre.component.html',
  styleUrls: ['./autre.component.css']
})
export class AutreComponent implements OnInit {

  constructor(private Service: ServicesService, private toastr: ToastrService, private l: LoadingBarService) {

  }

  ngOnInit(): void {
    this.getAutresL();
  }

  // page state
  active: boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  n: any = null;

  Autres: Autre[] = [];
  page: number = 1;
  // Forms variable
  SelectedA!: Autre;
  tarif: number = 0;
  libelle: string = "";
  // forms 
  box: boolean = false;

  Close(){
    this.box = false;
    this.Reset();
  }

  New() {
    this.Reset();
    this.box = true;
  }

  Reset() {
    this.SelectedA = this.n;
    this.tarif = 0;
    this.libelle = "";
  }

  Update() {
    if (!this.SelectedA) {
      this.toastr.warning("Veuillez selectionné l'élement à modifier");
    } else {
      this.box = true;
    }
  }

  Save() {
    if (this.SelectedA) {
      this.UpdateAutres();
    } else {
      this.NewAutres();
    }
  }

  SelectAutres(a: Autre) {
    this.SelectedA = a;
    this.libelle = a.libelle;
    this.tarif = a.tarif;
  }

  UpdateAutres() {
    this.SelectedA.libelle = this.libelle;
    this.SelectedA.tarif = this.tarif;
    this.loader.start();
    this.onsend = true;
    this.Service.UpdateAutres(this.SelectedA).subscribe(
      (res) => {
        this.box = false;
        this.Autres = res;
        this.toastr.success("Modification effetué");
        this.onsend = false;
        this.loader.complete();
        this.Reset();
      },
      (err) => {
        this.loader.complete();
        this.onsend = false;
        if (this.active) {
          this.Error(err);
        }
      }
    )
  }

  NewAutres() {
    let a = new Autre(this.libelle, this.tarif);
    this.loader.start();
    this.onsend = true;
    this.Service.NewAutres(a).subscribe(
      (res) => {
        this.box = false;
        this.Autres = res;
        this.toastr.success("Enregistrement effetué");
        this.onsend = false;
        this.loader.complete();
        this.Reset();
      },
      (err) => {
        this.loader.complete();
        this.onsend = false;
        if (this.active) {
          this.Error(err);
        }
      }
    )
  }

  Delete() {
    if (!this.SelectedA) {
      this.toastr.warning("Veuillez selectionné l'élement à supprimer");
    } else {
      if (confirm("Voulez vous vraiment supprimer cet service?")) {
        this.loader.start();
        this.onsend = true;
        this.Service.DeleteAutres(this.SelectedA).subscribe(
          (res) => {
            this.Autres = res;
            this.toastr.success("Suppression effetué");
            this.onsend = false;
            this.loader.complete();
            this.Reset();
          },
          (err) => {
            this.loader.complete();
            this.onsend = false;
            this.SelectedA.issup = true;
            this.UpdateAutres();
            if (this.active) {
              this.Error(err);
            }
          }
        )
      }
    }
  }

  // getData function
  getAutresL() {
    let a = this.Service.Autres;
    this.loader.start();
    if (a.length != 0) {
      this.Autres = a;
      this.loader.complete();
    } else {
      this.Service.getAutreSL().subscribe(
        (res) => {
          this.Autres = res;
          this.loader.complete();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getAutresL();
          }
        }
      )
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
