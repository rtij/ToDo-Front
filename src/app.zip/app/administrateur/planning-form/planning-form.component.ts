import { Time } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Autre } from 'src/app/Object/Autres';
import { Chambre } from 'src/app/Object/Chambre';
import { Client } from 'src/app/Object/Client';
import { Detailreservation } from 'src/app/Object/Detailreservation';
import { Detautre } from 'src/app/Object/Detautres';
import { detrestauration } from 'src/app/Object/Detrestauration';
import { Planning } from 'src/app/Object/Planning';
import { Reservation } from 'src/app/Object/Reservation';
import { Restauration } from 'src/app/Object/Restauration';
import { Typechambre } from 'src/app/Object/Typechambre';
import { Utilisateur } from 'src/app/Object/Utilisateur';
import { PlaningService } from 'src/app/Services/planing.service';
import { ServicesService } from 'src/app/Services/services.service';

@Component({
  selector: 'app-planning-form',
  templateUrl: './planning-form.component.html',
  styleUrls: ['./planning-form.component.css']
})
export class PlanningFormComponent implements OnInit {

  constructor(private Service: ServicesService, private toastr: ToastrService, private l: LoadingBarService, private PlanningService: PlaningService) {
  }

  ngOnInit(): void {
    this.getClient();
  }


  // page state
  active: boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  page: number = 1;
  // Data
  Clients: Client[] = [];
  TypeC: Typechambre[] = [];
  Chambres: Chambre[] = [];
  PlaningL: Planning[] = [];
  Restaurations: Restauration[] = [];
  Autres: Autre[] = [];
  // forms
  dater!: Date;
  state: boolean = false;
  Reservation!: Reservation;
  titre: string = "";
  nbad: number = 0;
  nbenf: number = 0;
  color: string = "";
  idutilisateur!: Utilisateur;
  idclient!: Client;
  note: string = "";
  nbchambre: number = 0;
  nbsalle: number = 0;
  avecp: boolean = false;
  nomc: string = "";
  // Client variables
  nom: string = "";
  tel: string = "";
  email: string = "";
  adresse: string = "";
  nationalite: string = "";
  nomag: string = "";
  agence: boolean = false;
  emailag: string = "";
  nif: string = "";
  stat: string = "";
  rc: string = "";
  box: boolean = false;
  // Planning variables
  dated!: Date;
  datea!: Date;
  heured!: Time;
  heurea!: Time;
  //                                                                                               
  typer: string = "Chambre";
  // 
  DetailRservation: Detailreservation[] = [];
  paged: number = 1;


  // TypeC forms variable
  nomtype: string = "";
  tarifT: number = 0;
  remiseT: number = 0;
  SelectedTypeC!: Typechambre;
  nbT: number = 0;

  // Planning box state
  Plannings: Planning[] = [];
  box4: boolean = false;
  SelectedC!: Chambre;
  nomch: string = "";


  // 
  ListeCh:Chambre[] = [];

  FilterChambreL(){
    let f = (c:Chambre)=>{
      let r = this.DetailRservation.find((item)=>{
        return item.idtypec.idtypec == c.idtypec.idtypec;
      });
      if(r){
        return true;
      }
      return false;
    }
    this.ListeCh = this.Chambres.filter((item)=>{
      return f(item);
    });
  }

  FindChambre(){
    let r= this.ListeCh.find((item)=>{
      return item.num == this.nomch
    });
    if(r){
      this.SelectedC = r;
    }else{
      this.SelectedC = this.n;
    }
  }

  NewCh() {
    this.box4 = true;
  }

  CloseCh() {
    this.box4 = false;
  }

  AddPlanning() {
    this.Plannings.push(new Planning(this.dated, this.datea, this.heured, this.heurea, this.SelectedC, this.Reservation));
  }

  RemoveP(i:number){
    this.Plannings.splice(i,1);
  }


  // Autre service
  liba: string = "";
  Detautres: Detautre[] = [];
  autren: string = "";
  nbra: number = 0;
  box3: boolean = false;
  pagea: number = 1;
  remisea: number = 0;
  tarifa: number = 0;
  SelectedA!: Autre;
  dureea: number = 0;

  // 
  findA() {
    let r = this.Autres.find((item) => {
      return item.libelle == this.liba;
    });
    if (r) {
      this.SelectedA = r;
      this.tarifa = r.tarif;
      return true;
    } else {
      this.SelectedA = this.n;
      this.tarifa = 0;
      return false;
    }
  }


  CloseA() {
    this.box3 = false;
    this.ResetA();
  }

  NewA() {
    this.box3 = true;
  }

  ResetA() {
    this.liba = "";
    this.autren = "";
    this.nbra = 0;
    this.remisea = 0;
    this.tarifa = 0;
  }

  AddAutre() {
    this.Detautres.push(new Detautre(this.SelectedA, this.nbra, this.Reservation, this.remisea, this.tarifa, this.dureea));
    this.ResetA();
  }

  RemoveA(i: number) {
    this.Detautres.splice(i, 1);
  }

  // Restauration box 
  Detrestauration: detrestauration[] = [];
  box2: boolean = false;
  nbr: number = 0;
  SelectedD!: Restauration;
  nomr: string = "";
  pager:number = 1;
  remise: number = 0;
  tarifr: number = 0;
  dureer: number = 0;

  FindRestauration() {
    let result = this.Restaurations.find((item) => {
      return item.libelle == this.nomr;
    });
    if (result) {
      this.SelectedD = result;
      this.tarifr = result.tarif;
      return true;
    } else {
      this.SelectedD = this.n;
      this.tarifr = 0;
      return false;
    }
  }

  CloseR() {
    this.box2 = false;
    this.ResetR();
  }

  NewR() {
    this.box2 = true;
    this.ResetR();
  }

  ResetR() {
    this.nomr = "";
    this.remise = 0;
    this.nbr = 0;
  }

  AddRestauration() {
    let r = new detrestauration(this.SelectedD, this.Reservation, this.nbr, ((this.SelectedD.tarif * this.nbr) * this.dureer) - (this.remise * this.dureer), this.remise, this.dureer);
    this.Detrestauration.push(r);
    this.ResetR();
  }


  RemoveRestauration(i: number) {
    this.Detrestauration.splice(i, 1);
  }
  //
  // Detailr box state
  box1: boolean = false;

  NewT() {
    this.box1 = true;
    this.ResetType();
  }

  Closed() {
    this.box1 = false;
    this.ResetType();
  }

  // 
  findTypeT() {
    let r = this.TypeC.find((item) => {
      return item.libelle == this.nomtype;
    });
    if (r) {
      this.SelectedTypeC = r;
      this.tarifT = r.tarif;
      return true;
    } else {
      this.SelectedTypeC = this.n;
      this.tarifT = 0;
      return false;
    }

  }

  AddDetailR() {
    this.DetailRservation.push(new Detailreservation(this.tarifT, this.remiseT, this.tarifT * this.nbT, this.SelectedTypeC, 0, this.nbT, this.Reservation));
    this.ResetType();
    this.FilterChambreL();
  }

  RemoveDetailr(i: number) {
    this.DetailRservation.splice(i, 1);
    this.FilterChambreL();
  }

  ResetType() {
    this.nomtype = '';
    this.SelectedTypeC = this.n;
    this.remiseT = 0;
    this.tarifT = 0;
    this.nbT = 0
  }

  // Forms check function
  CheckChambre() {
    let n = 0;
    this.DetailRservation.forEach((item) => {
      let r = this.Plannings.filter((it) => {
        return it.idchambre.idtypec.idtypec == item.idtypec.idtypec;
      });
      if(r.length == item.nbr){
        n +=1
      }
    });
    if(n == this.DetailRservation.length){
      return true;
    }
    return false;
  }

  // Save Form function start
  
  ResetF() {
    this.DetailRservation = [];
    this.Detrestauration = [];
    this.Reservation = this.n;
    this.datea = this.n;
    this.nomc = "";
    this.idclient = this.n;
    this.color = "";
    this.nbsalle = 0;
    this.nbad = 0;
    this.nbenf = 0;
    this.nbchambre = 0;
    this.dater = this.n;
    this.state = false;
    this.titre = "";
    this.note = "";

  }

  Save() {
    if (confirm("Voulez-vous vraiment enregistrer cette réservation ?")) {
      this.Reservation.iddetrestauration = this.Detrestauration;
      this.Reservation.iddetailr = this.DetailRservation;
      this.Reservation.idplanning = this.Plannings;
      if (this.Detrestauration.length > 0) {
        this.Reservation.avecp = true;
      }
      this.onsend = true;
      this.loader.start();
      this.PlanningService.NewReservation(this.Reservation).subscribe(
        (res) => {

          this.onsend = false;
          this.loader.complete();
          this.toastr.success("Enregistrement effectuer");
        },
        (err) => {
          this.onsend = false;
          this.loader.complete();
          if (this.active) {
            this.Error(err);
          }
        }
      )
    }
  }


  // Pagination 
  Next() {
    this.page += 1
  }

  Prev() {
    this.page -= 1;
  }
  // 
  findClient() {
    let r = this.Clients.find((item) => {
      return item.nom == this.nomc;
    });
    if (r) {
      this.idclient = r;
      return true
    } else {
      this.idclient = this.n;
      return false;
    }
  }

  // Client forms function

  CloseModal() {
    this.box = false;
    this.Reset();
  }

  NewC() {
    this.box = true;
    this.Reset();
  }

  Reset() {
    this.nom = '';
    this.email = "";
    this.nomag = "";
    this.tel = "";
    this.nationalite = "";
    if (this.agence) {
      this.agence = false;
      this.nomag = "";
      this.emailag = "";
      this.nif = "";
      this.stat = "";
      this.rc = "";
    }
  }

  // save client
  NewClient() {
    let c = new Client(this.nom, this.adresse, this.email, this.tel, this.nationalite, this.agence, this.emailag, "", this.nomag, this.nif, this.stat, this.rc);
    this.loader.start();
    this.onsend = true;
    this.Service.NewClient(c).subscribe(
      (res) => {
        this.onsend = false;
        this.Clients = res;
        this.Reset();
        this.box = false;
        this.toastr.success("Enregistrment  effectué");
        this.loader.complete();
      },
      (err) => {
        this.onsend = false;
        this.loader.complete();
        this.Error(err);
      }
    )
  }

  // getData function
  getClient() {
    let c = this.Service.Clients;
    this.loader.start();
    if (c.length != 0) {
      this.Clients = c;
      this.loader.complete();
      this.getTypeC();
    } else {
      this.Service.getClientL().subscribe(
        (res) => {
          this.Clients = res;
          this.loader.complete();
          this.getTypeC();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getClient();
          }
        }
      );
    }
  }

  getTypeC() {
    let t = this.Service.TypeChambres;
    this.loader.start();
    if (t.length != 0) {
      this.TypeC = t;
      this.loader.complete();
      this.getChambreL();
    } else {
      this.Service.getTypechambreL().subscribe(
        (res) => {
          this.TypeC = res;
          this.loader.complete();
          this.getChambreL();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getTypeC();
          }
        }
      );
    }
  }

  FilterChambre() {
    let f = (c: Chambre) => {
      let r = this.PlaningL.find((item) => {
        return item.idchambre.idchambre == c.idchambre && new Date(item.dated) >= new Date();
      });
      if (r) {
        return true;
      }
      return false;
    }
    this.Chambres = this.Chambres.filter((item) => {
      return !f(item);
    });
  }

  getChambreL() {
    let c = this.Service.Chambres;
    this.loader.start();
    if (this.Chambres.length) {
      this.Chambres = c;
      this.loader.complete();
      this.getAutresL();
    } else {
      this.Service.getChambreList().subscribe(
        (res) => {
          this.Chambres = res;
          this.loader.complete();
          this.getAutresL();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getChambreL();
          }
        }
      );
    }
  }

  getAutresL() {
    let a = this.Service.Autres;
    this.loader.start();
    if (a.length != 0) {
      this.Autres = a;
      this.loader.complete();
      this.getPlanningList();
    } else {
      this.Service.getAutreSL().subscribe(
        (res) => {
          this.Autres = res;
          this.loader.complete();
          this.getPlanningList();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getAutresL();
          }
        }
      )
    }
  }

  getPlanningList() {
    let p = this.PlanningService.Plannings;
    this.loader.start();
    if (p.length != 0) {
      this.PlaningL = p;
      this.loader.complete();
      this.FilterChambre();
      this.getRestauration();
    } else {
      this.PlanningService.getPlanningsL().subscribe(
        (res) => {
          this.PlaningL = res;
          this.loader.complete();
          this.FilterChambre();
          this.getRestauration();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getPlanningList();
          }
        }
      );
    }
  }

  getRestauration() {
    let r = this.Service.Restauration;
    this.loader.start();
    if (r.length != 0) {
      this.Restaurations = r;
      this.loader.complete();
    } else {
      this.Service.getRestauration().subscribe(
        (res) => {
          this.Restaurations = res;
          this.loader.complete();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getRestauration();
          }
        }
      );
    }
  }


  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
