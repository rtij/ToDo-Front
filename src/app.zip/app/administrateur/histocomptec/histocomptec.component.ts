import { Component } from '@angular/core';

@Component({
  selector: 'app-histocomptec',
  templateUrl: './histocomptec.component.html',
  styleUrls: ['./histocomptec.component.css']
})
export class HistocomptecComponent {

}
