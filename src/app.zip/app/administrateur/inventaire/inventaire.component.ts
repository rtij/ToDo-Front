import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Histoinventaire } from 'src/app/Object/Histoinventaire';
import { Stock } from 'src/app/Object/Stock';
import { ServicesService } from 'src/app/Services/services.service';
import { StockMService } from 'src/app/Services/stock-m.service';

@Component({
  selector: 'app-inventaire',
  templateUrl: './inventaire.component.html',
  styleUrls: ['./inventaire.component.css']
})
export class InventaireComponent implements OnInit {

  ngOnInit(): void {
    this.getStock();
  }

  constructor(private Service: ServicesService, private stockmService: StockMService, private toastr: ToastrService, private l: LoadingBarService) {

  }

  // page state
  active: boolean = true;

  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  page: number = 1;

  type: string = "Produit";
  // data

  Stocks: Stock[] = [];

  Produit: Stock[] = [];
  Matiere: Stock[] = [];

  // forms variable
  dateI!: Date;
  HistoI: Histoinventaire[] = [];
  SelectedS!: Stock;
  qte: number = 0;
  observation:string="";
  index:number = 0;

  // Save function start

  Save() {
    this.onsend = true;
    if(this.index < this.HistoI.length){
      this.HistoI[this.index].datei = this.dateI;
      this.loader.start();
      this.stockmService.newHistoinventaire(this.HistoI[this.index]).subscribe(
        (res)=>{
          this.loader.complete();
          this.index = this.index + 1;
          this.Save();
        },
        (err)=>{
          this.onsend = false;
          this.loader.complete();
          if(this.active){
            this.Error(err);
          }
        }
      );
    }else{
      this.index = 0;
      this.onsend = false;
      this.dateI = this.n;
      this.toastr.success("Enregistrement effectué");
      this.HistoI = [];
    }
  }

  // Find function

  AddH() {
    let r = this.FindHistoI(this.SelectedS);
    if (r) {
      this.HistoI = this.HistoI.filter((item) => {
        return item.idstock.idstock == this.SelectedS.idstock;
      });
      this.HistoI.push(new Histoinventaire(this.SelectedS.qte, this.qte, this.dateI, this.SelectedS, this.observation));
      this.Reset();
    } else {
      this.HistoI.push(new Histoinventaire(this.SelectedS.qte, this.qte, this.dateI, this.SelectedS, this.observation));
      this.Reset();
    }
  }

  Reset() {
    this.SelectedS = this.n;
    this.qte = 0;
  }

  SelectS(s: Stock) {
    this.SelectedS = s;
    let r = this.FindHistoI(s);
    if (r) {
      this.qte = r.qter;
    } else {
      this.qte = 0;
    }
  }

  FindHistoI(a: Stock) {
    let r = this.HistoI.find((item) => {
      return item.idstock.idstock == a.idstock;
    });
    if (r) {
      return r;
    }
    return null;
  }


  // Filter Data
  FilterMatiere() {
    this.Matiere = this.Stocks.filter((item) => {
      return item.type == true;
    });
    this.Matiere.forEach((item) => {
      item.qte = 0;
    });
  }

  FilterProduit() {
    this.Produit = this.Stocks.filter((item) => {
      return item.type == false;
    });
    this.Produit.forEach((item) => {
      item.qte = 0;
    });
  }

  // get Data function start
  getStock() {
    let s = this.Service.Stocks;
    let f = ()=>{
      this.Stocks = this.Stocks.filter((item)=>{
        return item.enstock == true;
      });
    }
    this.loader.start();
    if (s.length != 0) {
      this.Stocks = s;
      this.loader.complete();
      f();
      this.FilterMatiere();
      this.FilterProduit();
    } else {
      this.Service.getStock().subscribe(
        (res) => {
          this.Stocks = res;
          this.loader.complete();
          f();
          this.FilterMatiere();
          this.FilterProduit();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getStock();
          }
        }
      )
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
