import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Ingredient } from 'src/app/Object/Ingredient';
import { Stock } from 'src/app/Object/Stock';
import { ServicesService } from 'src/app/Services/services.service';

@Component({
  selector: 'app-fiche',
  templateUrl: './fiche.component.html',
  styleUrls: ['./fiche.component.css']
})
export class FicheComponent implements OnInit {


  constructor(private Service: ServicesService, private toastr: ToastrService, private l: LoadingBarService) {
  }

  ngOnInit(): void {
    this.getStock();
  }

  // page state
  active: boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  page: number = 1;

  Stocks: Stock[] = [];
  Produit: Stock[] = [];
  Matiere: Stock[] = [];
  // Forms Data
  SelectedS!: Stock;
  nomp: string = "";
  // Sous-forms variable
  m: string = "";
  qte: number = 0;
  SelectedM!: Stock;
  Ingredient: Ingredient[] = [];
  // 
  index = 0;


  // Forms fucntion
  findStock() {
    let r = this.Produit.find((item) => {
      return item.designation == this.nomp;
    });
    if (r) {
      this.Matiere = this.Stocks.filter((item) => {
        return item.idstock != r?.idstock;
      });
      this.SelectedS = r;
      this.Ingredient = r.idingredient;
      return true;
    } else {
      this.FilterProduit();
    }
    this.SelectedS = this.n;
    return false;
  }

  FindMatiere(): boolean {
    let r = this.Matiere.find((item) => {
      return item.designation == this.m;
    });
    if (r) {
      this.SelectedM = r;
      return true;
    }
    this.SelectedM = this.n;
    return false;
  }

  AddIngredient() {
    this.Ingredient.push(new Ingredient(this.SelectedS, this.SelectedM, this.qte));
    this.ResetM();
  }

  Remove(i: number) {
    if (this.SelectedS.idingredient.length != 0) {
      this.onsend = true;
      this.loader.start();
      this.Service.DeleteIngredient(this.Ingredient[i]).subscribe(
        (res) => {
          this.loader.complete();
          this.onsend = false;
          this.Stocks = res;
          this.Ingredient.splice(i, 1);
          this.toastr.success("Suppression effectué");
        },
        (err)=>{
          this.onsend = false;
          this.loader.complete();
          if(this.active){
            this.Error(err);
          }
        }
      )
    } else {
      this.Ingredient.splice(i, 1);
    }
  }

  ResetM() {
    this.qte = 0;
    this.SelectedM = this.n;
    this.m = "";
  }

  Reset() {
    this.Ingredient = [];
    this.SelectedS = this.n;
    this.nomp = "";
  }

  Save() {
    this.onsend = true;
    if (this.index < this.Ingredient.length) {
      this.loader.start();
      this.Service.CreateIngredient(this.Ingredient[this.index]).subscribe(
        (res) => {
          this.Stocks = res;
          this.loader.complete();
          this.index = this.index + 1;
          this.Save();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.onsend = false;
          }
        }
      )
    } else {
      this.onsend = false;
      this.Reset();
      this.toastr.success("Enegistrement effectué");
    }
  }

  // Filter Data

  FilterMatiere() {
    this.Matiere = this.Stocks.filter((item) => {
      return item.type == true;
    });
  }

  FilterProduit() {
    this.Produit = this.Stocks.filter((item) => {
      return item.type == false && item.transformer == true;
    });
  }

  // get Data function start

  getStock() {
    let s = this.Service.Stocks;
    this.loader.start();
    if (s.length != 0) {
      this.Stocks = s;
      this.loader.complete();
      this.FilterMatiere();
      this.FilterProduit();
    } else {
      this.Service.getStock().subscribe(
        (res) => {
          this.Stocks = res;
          this.loader.complete();
          this.FilterMatiere();
          this.FilterProduit();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getStock();
          }
        }
      )
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
