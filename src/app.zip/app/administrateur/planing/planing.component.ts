import { Component } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Chambre } from 'src/app/Object/Chambre';
import { Client } from 'src/app/Object/Client';
import { Planning } from 'src/app/Object/Planning';
import { Typechambre } from 'src/app/Object/Typechambre';
import { PlaningService } from 'src/app/Services/planing.service';
import { ServicesService } from 'src/app/Services/services.service';

@Component({
  selector: 'app-planing',
  templateUrl: './planing.component.html',
  styleUrls: ['./planing.component.css']
})
export class PlaningComponent {
  constructor(private Service: ServicesService, private toastr: ToastrService, private l: LoadingBarService, private PlanningService: PlaningService) {
  }

  ngOnInit(): void {
    this.getClient();
  }


  // page state
  active: boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  page: number = 1;
  // Data
  Clients: Client[] = [];
  TypeC: Typechambre[] = [];
  Chambres: Chambre[] = [];
  PlaningL:Planning[] = [];




  // getData function
  getClient() {
    let c = this.Service.Clients;
    this.loader.start();
    if (c.length != 0) {
      this.Clients = c;
      this.loader.complete();
      this.getTypeC();
    } else {
      this.Service.getClientL().subscribe(
        (res) => {
          this.Clients = res;
          this.loader.complete();
          this.getTypeC();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getClient();
          }
        }
      );
    }
  }

  getTypeC() {
    let t = this.Service.TypeChambres;
    this.loader.start();
    if (t.length != 0) {
      this.TypeC = t;
      this.loader.complete();
      this.getChambreL();
    } else {
      this.Service.getTypechambreL().subscribe(
        (res) => {
          this.TypeC = res;
          this.loader.complete();
          this.getChambreL();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getTypeC();
          }
        }
      );
    }
  }

  getChambreL() {
    let c = this.Service.Chambres;
    this.loader.start();
    if (this.Chambres.length) {
      this.Chambres = c;
      this.loader.complete();
      this.getPlanningList();
    } else {
      this.Service.getChambreList().subscribe(
        (res) => {
          this.Chambres = res;
          this.loader.complete();
          this.getPlanningList();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getChambreL();
          }
        }
      );
    }
  }

  getPlanningList() {
    let p = this.PlanningService.Plannings;
    this.loader.start();
    if (p.length != 0) {
      this.PlaningL = p;
      this.loader.complete();
    } else {
      this.PlanningService.getPlanningsL().subscribe(
        (res) => {
          this.PlaningL = res;
          this.loader.complete();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getPlanningList();
          }
        }
      )
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
