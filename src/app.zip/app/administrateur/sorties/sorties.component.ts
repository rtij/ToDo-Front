import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Details } from 'src/app/Object/Details';
import { Sortie } from 'src/app/Object/Sortie';
import { Stock } from 'src/app/Object/Stock';
import { ServicesService } from 'src/app/Services/services.service';
import { StockMService } from 'src/app/Services/stock-m.service';

@Component({
  selector: 'app-sorties',
  templateUrl: './sorties.component.html',
  styleUrls: ['./sorties.component.css']
})
export class SortiesComponent implements OnInit {

  constructor(private Service: ServicesService, private StockmService: StockMService, private l: LoadingBarService, private toastr: ToastrService) { }

  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.getStock();
  }

  // page state
  active: boolean = true;
  // 
  loader = this.l.useRef();
  // Data
  Stocks: Stock[] = [];
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  page: number = 1;
  // Forms variable
  dateS!: Date;
  numb: string = "";
  // 
  nomS: string = "";
  SelectedS!: Stock;
  affectation: string = "";
  qte: number = 0;

  // 
  Sortie!: Sortie;
  Details: Details[] = [];
  index: number = 0;

  // Forms function
  Save() {
    this.onsend = true;
    this.loader.start();
    this.StockmService.NewSortie(this.Sortie).subscribe(
      (res) => {
        this.loader.complete();
        this.Sortie = res;
        this.SaveDetails();
      },
      (err) => {
        this.onsend = false;
        this.loader.complete();
        if (this.active) {
          this.Error(err);
        }
      }
    )
  }

  SaveDetails() {
    if (this.index < this.Details.length) {
      this.loader.start();
      this.Details[this.index].idsortie = this.Sortie;
      this.StockmService.NewDetails(this.Details[this.index]).subscribe(
        (res) => {
          this.Stocks = res;
          this.Service.Stocks = res;
          this.FilterStock();
          this.index = this.index + 1;
          this.loader.complete();
          this.SaveDetails();
        },
        (err) => {
          this.onsend = false;
          this.loader.complete();
          if (this.active) {
            this.Error(err);
          }
        }
      )
    } else {
      this.loader.complete();
      this.Reset();
      this.toastr.success("Enregistrement effectué");
    }
  }

  Reset() {
    this.Details = [];
    this.onsend = false;
    this.dateS = this.n;
    this.index = 0;
    this.numb = "";
  }

  Add() {
    if (!this.Sortie) {
      this.Sortie = new Sortie(this.numb, this.dateS);
    }
    this.Details.push(new Details(this.SelectedS, this.qte, this.Sortie, this.affectation));
    this.Resetf();
  }


  Resetf() {
    this.qte = 0;
    this.SelectedS = this.n;
    this.nomS = "";
    this.affectation = "";
  }

  Remove(i: number) {
    this.Details.splice(i, 1);
  }

  // FilterData

  FindStock() {
    let r = this.Stocks.find((item) => {
      return item.designation == this.nomS;
    });
    if (r) {
      this.SelectedS = r;
    } else {
      this.SelectedS = this.n;
    }
  }

  // getData function start

  FilterStock() {
    this.Stocks = this.Stocks.filter((item) => {
      return item.type == true;
    });
  }

  getStock() {
    let s = this.Service.Stocks;
    this.loader.start();
    if (s.length != 0) {
      this.Stocks = s;
      this.FilterStock();
      this.loader.complete();
    } else {
      this.Service.getStock().subscribe(
        (res) => {
          this.Stocks = res;
          this.FilterStock();
          this.loader.complete();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getStock();
          }
        }
      )
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
