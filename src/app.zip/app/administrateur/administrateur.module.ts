import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdministrateurRoutingModule } from './administrateur-routing.module';
import { AdministrateurComponent } from './administrateur.component';
import { ParamsComponent } from './params/params.component';
import { UtilisateurComponent } from './utilisateur/utilisateur.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LoadingBarModule } from '@ngx-loading-bar/core';
import { LoadingBarRouterModule } from '@ngx-loading-bar/router';
import { HttpClientModule } from '@angular/common/http';
import { ToastrModule } from 'ngx-toastr';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { DepenseComponent } from './depense/depense.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { TypechambreComponent } from './typechambre/typechambre.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RestaurationComponent } from './restauration/restauration.component';
import { ClientComponent } from './client/client.component';
import { HistocomptecComponent } from './histocomptec/histocomptec.component';
import { StockComponent } from './stock/stock.component';
import { VenteComponent } from './vente/vente.component';
import { PlaningComponent } from './planing/planing.component';
import { PaiementComponent } from './paiement/paiement.component';
import { ChargeComponent } from './charge/charge.component';
import { ProduitComponent } from './produit/produit.component';
import { AgGridModule } from 'ag-grid-angular';
import { NgxPrintModule } from 'ngx-print';
import { FicheComponent } from './fiche/fiche.component';
import { SortiesComponent } from './sorties/sorties.component';
import { EntreesComponent } from './entrees/entrees.component';
import { InventaireComponent } from './inventaire/inventaire.component';
import { JournalComponent } from './journal/journal.component';
import { HistoriqueSComponent } from './historique-s/historique-s.component';
import { JournaliComponent } from './journali/journali.component';
import { JournaleComponent } from './journale/journale.component';
import { JournalSComponent } from './journal-s/journal-s.component';
import { EnregistrementComponent } from './enregistrement/enregistrement.component';
import { PlanningFormComponent } from './planning-form/planning-form.component';
import { AutreComponent } from './autre/autre.component';


@NgModule({
  declarations: [
    AdministrateurComponent,
    ParamsComponent,
    UtilisateurComponent,
    DepenseComponent,
    TypechambreComponent,
    DashboardComponent,
    RestaurationComponent,
    ClientComponent,
    HistocomptecComponent,
    StockComponent,
    VenteComponent,
    PlaningComponent,
    PaiementComponent,
    ChargeComponent,
    ProduitComponent,
    FicheComponent,
    SortiesComponent,
    EntreesComponent,
    InventaireComponent,
    JournalComponent,
    HistoriqueSComponent,
    JournaliComponent,
    JournaleComponent,
    JournalSComponent,
    EnregistrementComponent,
    PlanningFormComponent,
    AutreComponent
  ],
  imports: [
    CommonModule,
    AdministrateurRoutingModule, 
    FormsModule, 
    LoadingBarModule,
    LoadingBarRouterModule,
    AgGridModule,
    NgxPrintModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgxPaginationModule,
    ToastrModule.forRoot(),
    Ng2SearchPipeModule,
  ]
})
export class AdministrateurModule { }
