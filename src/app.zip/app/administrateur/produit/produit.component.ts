import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Famille } from 'src/app/Object/Famille';
import { Stock } from 'src/app/Object/Stock';
import { Unite } from 'src/app/Object/Unite';
import { ServicesService } from 'src/app/Services/services.service';

@Component({
  selector: 'app-produit',
  templateUrl: './produit.component.html',
  styleUrls: ['./produit.component.css']
})
export class ProduitComponent implements OnInit {

  constructor(private Service: ServicesService, private toastr: ToastrService, private l: LoadingBarService) {
  }

  ngOnInit(): void {
    this.getFamille();
  }

  // page state
  active: boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  page: number = 1;

  type: string = "Produit";

  // forms state
  box: boolean = false;
  box1: boolean = false;
  box2: boolean = false;

  // Data
  Familles: Famille[] = [];
  Unites: Unite[] = [];
  Stocks: Stock[] = [];

  Produit: Stock[] = [];
  Matiere: Stock[] = [];
  pagep: number = 1;
  pagem: number = 1;

  // Forms variable
  // famille forms
  libellef: string = "";
  libf: string = "";
  SelectedF!: Famille;

  // unite forms
  unite: string = "";
  SelectedU!: Unite;
  u: string = "";

  // Stock variable
  designation: string = "";
  transformer: boolean = false;
  code: string = "";
  pvu: number = 0;
  pru: number = 0;
  seuil: number = 0;
  SelectedS!: Stock;
  enstock: boolean = false;


  // Unite modal function
  FindU(){
    if(this.SelectedU){
      let r = this.Unites.find((item)=>{
        return item.unite == this.u;
      });
      if( r?.idunite != this.SelectedU.idunite){
        return true;
      }
    }else{
      let r = this.Unites.find((item)=>{
        return item.unite == this.unite;
      });
      if(r){
        return true;
      }
    }    
    return false;
  }

  CloseModalU() {
    this.box2 = false;
  }

  ShowU() {
    this.box2 = true;
    this.unite = "";
    this.SelectedU = this.n;
  }

  SelectUnite(u: Unite) {
    this.SelectedU = u;
    this.u = u.unite;
  }

  UpdateUnite() {
    if (this.FindU() || this.u == this.SelectedU.unite) {
      this.SelectedU = this.n;
    } else {
      this.SelectedU.unite = this.u;
      this.loader.start();
      this.onsend = true;
      this.Service.UpdateUnite(this.SelectedU).subscribe(
        (res) => {
          this.loader.complete();
          this.onsend = false;
          this.Unites = res;
          this.SelectedU = this.n;
          this.u = "";
          this.toastr.success("Modification effectué");
        },
        (err) => {
          this.onsend = false;
          this.loader.complete();
          this.Error(err);
        }
      )
    }
  }

  Newunite() {
    let u = new Unite(this.unite);
    this.loader.start();
    this.onsend = true;
    this.Service.newUnite(u).subscribe(
      (res) => {
        this.loader.complete();
        this.Unites = res;
        this.unite = "";
        this.toastr.success("Enregistrement effectuer");
        this.onsend = false;
      },
      (err) => {
        this.Error(err);
        this.loader.complete();
        this.onsend = false;
      }
    )
  }

  // Famille modal function
  CloseModalF() {
    this.box1 = false;
  }

  ShowF() {
    this.box1 = true;
    this.libellef = "";
    this.SelectedF = this.n;
  }

  SelectFamille(f: Famille) {
    this.SelectedF = f;
    this.libf = f.libelle;
  }

  UpdateFamille() {
    let f = ()=>{
      let r = this.Familles.find((item)=>{
        return item.libelle == this.libf;
      });
      if(r?.idfamille != this.SelectedF.idfamille){
        return true;
      }
      return false;
    }
    if (f() || this.libf == this.SelectedF.libelle) {
      this.SelectedF = this.n;
    } else {
      this.SelectedF.libelle = this.libf;
      this.loader.start();
      this.onsend = true;
      this.Service.UpdateFamille(this.SelectedF).subscribe(
        (res) => {
          this.Familles = res;
          this.libf = "";
          this.SelectedF = this.n;
          this.toastr.success("Modification effectué");
          this.loader.complete();
        },
        (err) => {
          this.Error(err);
          this.loader.complete();
          this.onsend = false;
        }
      );
    }
  }

  NewF() {
    let f = new Famille(this.libellef);
    this.loader.start();
    this.onsend = true;
    this.Service.createFamille(f).subscribe(
      (res) => {
        this.libellef = "";
        this.onsend = false;
        this.Familles = res;
        this.loader.complete();
        this.toastr.success("Enregistrement effectué");
      },
      (err) => {
        this.loader.complete();
        this.onsend = false;
        this.Error(err);
      }
    )
  }

  // Stocks
  IsExistingP():boolean{
    let r = this.Stocks.find((item)=>{
      return item.code == this.code || this.designation == item.designation;
    });
    if(this.SelectedS && this.SelectedS.idstock == r?.idstock){
      return true;
    }else if(!this.SelectedS && r){
      return true
    }
    return false;
  }

  SelectStock(s:Stock){
    this.SelectedS = s;
    this.SelectedU = s.idunite;
    this.SelectedF = s.idfamille;
    this.designation= s.designation;
    this.code = s.code;
    this.libellef = s.idfamille.libelle;
    this.unite = s.idunite.unite;
    this.pru = s.pra;
    this.pvu = s.pvu;
    this.seuil = s.seuil;
    this.transformer = s.transformer;
    this.enstock = s.enstock;
  }

  FindUnite() {
    let r = this.Unites.find((item) => {
      return item.unite == this.unite;
    });
    if (r) {
      this.SelectedU = r;
    } else {
      this.SelectedU = this.n;
    }
  }

  FindFamille() {
    let r = this.Familles.find((item) => {
      return item.libelle == this.libellef;
    });
    if (r) {
      this.SelectedF = r;
    } else {
      this.SelectedF = this.n;
    }

  }

  Reset() {
    this.SelectedS = this.n;
    this.SelectedF = this.n;
    this.SelectedU = this.n;
    this.designation = "";
    this.pru = 0;
    this.libellef = "";
    this.code = "";
    this.seuil = 0;
    this.enstock = false;
    this.transformer = false;
    this.pvu = 0;
    this.unite = "";
  }

  NewStock() {
    this.Reset();
    this.box = true;
  }

  UpdateS(){
    if(!this.SelectedS){
      this.toastr.warning("Veuillez selectionner l'élement à modifier");
    }else{
      this.box = true;
    }
  }

  Close() {
    this.box = false;
    this.Reset();
  }

  Save() {
    if (!this.SelectedS) {
      this.SaveNewStock();
    } else {
      this.UpdateStock();
    }
  }

  SaveNewStock() {
    let p: boolean = false;
    if (this.type == "Matière") {
      p = true;
    }
    let s = new Stock(p, this.enstock, this.code, this.designation, this.seuil, this.pru, this.pvu, this.SelectedU, this.SelectedF, this.transformer);
    this.loader.start();
    this.Service.newStock(s).subscribe(
      (res) => {
        this.Reset();
        this.loader.complete();
        this.Stocks = res;
        this.toastr.success("Enregistrement effectué");
        this.box = false;
        this.onsend = false;
        this.FilterMatiere();
        this.FilterProduit();
      },
      (err) => {
        this.Error(err);
        this.loader.complete();
        this.onsend = false;
      }
    );
  }

  UpdateStock() {
    this.SelectedS.code = this.code;
    this.SelectedS.designation = this.designation;
    this.SelectedS.idunite = this.SelectedU;
    this.SelectedS.idfamille = this.SelectedF;
    this.SelectedS.pra = this.pru;
    this.SelectedS.enstock = this.enstock;
    this.SelectedS.pvu = this.pvu;
    this.SelectedS.transformer = this.transformer;
    this.loader.start();
    this.onsend = true;
    this.Service.updateStock(this.SelectedS).subscribe(
      (res) => {
        this.Reset();
        this.loader.complete();
        this.Stocks = res;
        this.toastr.success("Modification effectué");
        this.FilterMatiere();
        this.FilterProduit();
        this.box = false;
        this.onsend = false;
      },
      (err) => {
        this.Error(err);
        this.loader.complete();
        this.onsend = false;
      }
    );
  }

  DeleteStock() {
    if (!this.SelectedS) {
      this.toastr.warning("Veuillez selectioner l'article à supprimer");
    } else {
      if (confirm("Voulez-vous vraiment supprimer cette article ?")) {
        this.loader.start();
        this.onsend = true;
        this.Service.DeleteStock(this.SelectedS).subscribe(
          (res) => {
            this.onsend = false;
            this.Reset();
            this.loader.complete();
            this.Stocks = res;
            this.toastr.success("Suppression effectué");
            this.FilterMatiere();
            this.FilterProduit();
          },
          (err) => {
            this.Error(err);
            this.onsend = false;
            this.loader.complete();
            this.SelectedS.issup = true;
            this.UpdateStock();
          }
        );
      }
    }
  }

  // Filter Data

  FilterMatiere() {
    this.Matiere = this.Stocks.filter((item) => {
      return item.type == true;
    });
  }

  FilterProduit() {
    this.Produit = this.Stocks.filter((item) => {
      return item.type == false;
    });
  }

  // getData function
  getFamille() {
    let f = this.Service.Familles;
    this.loader.start();
    if (f.length != 0) {
      this.Familles = f;
      this.loader.complete();
      this.getStock();
    } else {
      this.Service.getFamilleListe().subscribe(
        (res) => {
          this.Familles = res;
          this.loader.complete();
          this.getStock();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getFamille();
          }
        }
      );
    }
  }

  getUnite() {
    let u = this.Service.Unites;
    if (u.length != 0) {
      this.Unites = u;
      this.loader.complete();
    } else {
      this.Service.getUniteListe().subscribe(
        (res) => {
          this.Unites = res;
          this.loader.complete;
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getUnite();
          }
        }
      );
    }
  }

  getStock() {
    let s = this.Service.Stocks;
    this.loader.start();
    if (s.length != 0) {
      this.Stocks = s;
      this.loader.complete();
      this.FilterMatiere();
      this.FilterProduit();
      this.getUnite();
    } else {
      this.Service.getStock().subscribe(
        (res) => {
          this.Stocks = res;
          this.loader.complete();
          this.FilterMatiere();
          this.FilterProduit();
          this.getUnite();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getStock();
          }
        }
      )
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }

  ngOnDestroy(): void {
    //Called once, before the instance is destroyed.
    //Add 'implements OnDestroy' to the class.
    this.active = false;
  }
}
