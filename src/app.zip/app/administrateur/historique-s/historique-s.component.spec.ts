import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HistoriqueSComponent } from './historique-s.component';

describe('HistoriqueSComponent', () => {
  let component: HistoriqueSComponent;
  let fixture: ComponentFixture<HistoriqueSComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ HistoriqueSComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(HistoriqueSComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
