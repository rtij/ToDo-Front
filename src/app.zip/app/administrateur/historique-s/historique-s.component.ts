import { Component, OnInit } from '@angular/core';
import { LoadingBarService } from '@ngx-loading-bar/core';
import { ToastrService } from 'ngx-toastr';
import { Histostock } from 'src/app/Object/Histostock';
import { Stock } from 'src/app/Object/Stock';
import { ServicesService } from 'src/app/Services/services.service';
import { StockMService } from 'src/app/Services/stock-m.service';

@Component({
  selector: 'app-historique-s',
  templateUrl: './historique-s.component.html',
  styleUrls: ['./historique-s.component.css']
})
export class HistoriqueSComponent implements OnInit {

  constructor(private Service: ServicesService, private StockmService: StockMService, private l: LoadingBarService, private toastr: ToastrService) { }

  ngOnInit(): void {
    this.getStock();
  }

  // page state
  active: boolean = true;
  // 
  loader = this.l.useRef();
  onsend: boolean = false;
  search: string = '';
  n: any = null;
  page: number = 1;

  // Data
  Stocks: Stock[] = [];
  Histostock: Histostock[] = [];
  Result: Histostock[] = [];
  // Search
  date1!: Date;
  date2!: Date;
  SelectedS!: Stock;
  nomP:string="";

  // Filter
  findS(){
    let r = this.Stocks.find((item)=>{
      return item.designation == this.nomP;
    });
    if(r){
      this.SelectedS = r;
      if(this.date1 && this.date2){
        this.FilterDate();
      }else{
        this.Result = this.Histostock.filter((item)=>{
          return item.idstock.idstock == this.SelectedS.idstock;
        });
      }
    }else{
      this.SelectedS = this.n;
      this.Result = [];
    }
  }

  FilterDate(){
    if ((this.date1 && this.date2) && this.SelectedS) {
      this.Result = this.Histostock.filter((item) => {
        return item.idstock.idstock == this.SelectedS.idstock && (this.date1 <= new Date(item.dateh) && this.date2 >= new Date(item.dateh));
      });
    } else {
      this.Result = this.Histostock;
    }
  }


  // FilterData
  FilterStock() {
    this.Stocks = this.Stocks.filter((item) => {
      return item.enstock == true;
    });
  }

  // getData function
  getStock() {
    let s = this.Service.Stocks;
    this.loader.start();
    if (s.length != 0) {
      this.Stocks = s;
      this.loader.complete();
      this.FilterStock();
      this.getHistostock();
    } else {
      this.Service.getStock().subscribe(
        (res) => {
          this.Stocks = res;
          this.loader.complete();
          this.FilterStock();
          this.getHistostock();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getStock();
          }
        }
      )
    }
  }

  getHistostock() {
    this.loader.start();
    let h = this.StockmService.HistoS;
    if (h.length != 0) {
      this.Histostock = h;
      this.findS();
      this.loader.complete();
    } else {
      this.StockmService.getHistoStockList().subscribe(
        (res) => {
          this.Histostock = res;
          this.findS();
          this.loader.complete();
        },
        (err) => {
          this.loader.complete();
          if (this.active) {
            this.Error(err);
            this.getHistostock();
          }
        }
      )
    }
  }

  Error(error: any) {
    this.loader.complete();
    if (error.error['message'] && error.error['message'] != "Expired JWT Token") {
      console.log(error.error);
      this.toastr.warning("Server error");
    }
  }


  ngOnDestroy() {
    this.active = false;
  }
}
